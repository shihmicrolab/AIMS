function [  ] = save_coordinates( handles )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

mastertableData = get(handles.masterTable,'Data');

saved_coordinates = zeros(104,2);

for i = 1:1:104
    
    saved_coordinates(i,1) = mastertableData(i,2);
    saved_coordinates(i,2) = mastertableData(i,3);
    
end

% Saving coordinates to workspace (.mat file)

prompt = {'Save: '};
            dlg_title = 'Save coordinates';
            num_lines = 1;
            defaultans = {'name'};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            
            answer_text = cell2mat(answer);

filename = answer_text;

save(strcat('coordinates_',filename), 'saved_coordinates');

end