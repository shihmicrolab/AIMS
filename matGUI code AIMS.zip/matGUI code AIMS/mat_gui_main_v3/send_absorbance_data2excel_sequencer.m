function [  ] = send_absorbance_data2excel_sequencer( handles,luxvaluesData,counter,numberReadings,number2Average )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

lux_Filename_send = sprintf('lux_%s_%d.txt', datestr(now,'mm-dd-yyyy-HH-MM'),counter);
od_Filename_send = sprintf('od_%s_%d.xlsx', datestr(now,'mm-dd-yyyy-HH-MM'),counter);

% Save All LUX Values to excel %

luxValuesFile = luxvaluesData;

save(lux_Filename_send,'luxValuesFile','-ascii');

%% Weird thing here ...

% Save All LUX Values to excel %

% Send Lux Values to Table %

% Get absorbance table Data

absorbancetableData = get(handles.absorbanceTable,'Data');

% Get the lux Values

luxValuesFile = luxvaluesData;

% Init the average lux value to be sent to table

summingLux = 0;

% Init the position of the average lux value to be sent to
% table

averageLux_counter = 0;

% Calculating the average for Lux and sending it to absorbance Table

for i = 1:1:numberReadings
    
    summingLux = luxValuesFile(i,1) +  summingLux;
    
    % Looking at when to stop and take the average
    
    if mod(i,number2Average) == 0
        
        averageLux_counter = averageLux_counter + 1;
        
        averageLux_send = summingLux/number2Average;
        
        absorbancetableData {averageLux_counter,1} = averageLux_send;
        
        % Convert it to OD
        
        absorbancetableData {averageLux_counter,2} = lux_2_OD( str2double(get(handles.blankluxEdittext,'String')),averageLux_send );
        
        % Reinit the average Lux value
        
        summingLux = 0;
        
    end
    
end

% Set absorbance table Data

set(handles.absorbanceTable,'Data',absorbancetableData);

% Send Lux Values to Table %


% Save Lux + OD to Excel %

%% Sending to excel

% Get absorbance table Data

absorbancetableData = get(handles.absorbanceTable,'Data');

%             %FileName =['OD_',datestr(now, 'ddd-mm-yyyy_HH:MM:SS'),'_.xlsx'];
%             FileName =['OD_',datestr(now, 'ddd-mm-yyyy'),'_.xlsx'];

absorbancetableData_converted =  cell2table(absorbancetableData);

writetable(absorbancetableData_converted,od_Filename_send);

% Reinit the absorbance table

for i = 1:1:numberReadings
    
    absorbancetableData{i,1} = '';
    absorbancetableData{i,2} = '';
    
end

% Set absorbance table Data

set(handles.absorbanceTable,'Data',absorbancetableData);

% Save Lux + OD to Excel %



end

