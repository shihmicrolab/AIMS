function [  ] = color_electrode_pad_blink( electrode_number,color_pad, number_blink , handles )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

mastertableData = get(handles.masterTable,'Data');

i = mastertableData(electrode_number,6);

j = mastertableData(electrode_number,7);

for n = 1:1:number_blink

set(handles.Electrode_pad(i,j),'Backgroundcolor',color_pad);

pause (0.01);

set(handles.Electrode_pad(i,j),'Backgroundcolor','white');

pause (0.01);


end

end