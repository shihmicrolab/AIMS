function [ ] = draw_user_grid( handles, gridName)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

%lineObj = draw_point2point_line( pnt1, pnt2 )

% have to save the reference points first
% take gridName
% load in the array file
% depending on number of points int here -> for loop -> draw that many
% lines
%assuming the drawing of point is clockwise
%draw_point2point_line -> pnt1 -> pnt2

visual_coordinates = load(gridName);

dataSize = size(visual_coordinates.visual_grid_coordinates);

for i = 1:1:dataSize(1)
    
    if i == dataSize(1)
        
        pnt1 = [visual_coordinates.visual_grid_coordinates(i,1) visual_coordinates.visual_grid_coordinates(i,2)];
        pnt2 = [visual_coordinates.visual_grid_coordinates(1,1) visual_coordinates.visual_grid_coordinates(1,2)];
        
        draw_point2point_line(handles, pnt1, pnt2 );
        continue;
    end
    
    pnt1 = [visual_coordinates.visual_grid_coordinates(i,1) visual_coordinates.visual_grid_coordinates(i,2)];
    pnt2 = [visual_coordinates.visual_grid_coordinates(i+1,1) visual_coordinates.visual_grid_coordinates(i+1,2)];
    
    draw_point2point_line(handles, pnt1, pnt2 );
    
end

end

