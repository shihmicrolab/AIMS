function [  ] = save_coordinates_button( handles, hObject )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

if get(handles.savecoordinateRadiobutton,'Value') == 1
    
    disp_command(handles,'Save Coordinates activated');
    
    mastertableData = get(handles.masterTable,'Data');
    
    prompt = {'X:' ,'Y:'};
    dlg_title = 'Save grid coordinates';
    num_lines = 1;
    defaultans = {'0','0'};
    answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
    
    electrode_number =  str2double(get(hObject,'String'));
    
    for i = 1:1:104
        
        if mastertableData(i,1) == electrode_number
            mastertableData(i,2)= str2double(cell2mat(answer(1)));
            mastertableData(i,3)= str2double(cell2mat(answer(2)));
        end
       
    end
    
    set(handles.masterTable,'Data',mastertableData);
    
end

end

