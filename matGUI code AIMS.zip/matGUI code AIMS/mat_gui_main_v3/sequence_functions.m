function [  ] = sequence_functions( charCommand )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

switch charCommand
    
    case 'A'
        
    case 'T'

end

