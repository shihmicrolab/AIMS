function [ continue_statement ] = special_character_in_sequence_no_abs( handles,j )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
%% Getting tables Data

sequencetableData = get(handles.sequenceTable,'Data');


%% Special Characters here

if ischar(sequencetableData{1,j}) == 1
    
    if sequencetableData{1,j} == 'T' % Paused Time
        
        disp('Pause Started on : ')
        disp(datetime('now'))
        
        pause(str2double(sequencetableData{2,j}));
        
        continue_statement = true;
        
        %     elseif sequencetableData{1,j} == 'O' % Blank OD reading
        %
        %         blankValue = get_absorbance_value(handles);
        %         %blankValue = 1000;
        %
        %         set(handles.blankluxEdittext,'String',num2str(blankValue));
        %
        %         continue_statement = true;
        
    elseif sequencetableData{1,j} == 'V' % Voltage Change
        
        voltage2send = str2double(sequencetableData{2,j});
        
        set(handles.functionGvoltageEdittext,'String',sequencetableData{2,j});
        
        voltage_control( handles,voltage2send );
        
        continue_statement = true;
        
    elseif sequencetableData{1,j} == 'AT' % Acutation Time Change
        
        actuation_time = str2double(sequencetableData{2,j});
        
        set(handles.timeEdittext,'String',num2str(actuation_time));
        
        continue_statement = true;
        
        %     elseif sequencetableData{1,j} == 'A' % OD reading
        %
        %         % Absorbance Value -> is really just Lux (should be FIXED)
        %
        %         absorbancevalue_Counter = absorbancevalue_Counter + 1;
        %
        %         absorbanceValue = get_absorbance_value(handles);
        %         %absorbanceValue = 150;
        %
        %         luxtableData{absorbancevalue_Counter,1} = absorbanceValue;
        %         luxtableData{absorbancevalue_Counter,2} = toc;
        %
        %         set(handles.luxTable,'Data',luxtableData);
        %
        %         absorbance_value_text = strcat('Absorbance Value: ',num2str(absorbanceValue));
        %
        %         disp_command(handles,absorbance_value_text);
        %
        %         luxvaluesData(absorbancevalue_Counter,1) = absorbanceValue;
        %
        %         counter4time = counter4time + 1 ;
        %
        %         % Input the time it was recorded
        %
        %         if mod(counter4time,number2Average) == 0
        %
        %             time_counter = time_counter + 1;
        %
        %             absorbancetableData {time_counter,3} = toc;
        %
        %             set(handles.absorbanceTable,'Data',absorbancetableData);
        %
        %             % Input the Lux and OD also
        %
        %             summingLuxTemp = 0;
        %
        %             for k = 0:1:number2Average - 1
        %
        %                 summingLuxTemp = luxvaluesData(absorbancevalue_Counter - k,1) + summingLuxTemp;
        %
        %             end
        %
        %             % Average the Lux
        %
        %             averageLuxTemp_send = summingLuxTemp/number2Average;
        %
        %             absorbancetableData {time_counter,1} = averageLuxTemp_send;
        %
        %             % output the OD
        %
        %             absorbancetableData {time_counter,2} = lux_2_OD( str2double(get(handles.blankluxEdittext,'String')),averageLuxTemp_send );
        %
        %             set(handles.absorbanceTable,'Data',absorbancetableData);
        %
        %             %         % Sending values to Live Graph
        %             %
        %             %         % OD value to send
        %             %
        %             %         odValueGraph = lux_2_OD( str2double(get(handles.blankluxEdittext,'String')),averageLuxTemp_send );
        %             %
        %             %         % Get current time
        %             %         t =  datetime('now') - startTime;
        %             %
        %             %         % Add points to animation
        %             %         addpoints(odLine,datenum(t),odValueGraph);
        %             %
        %             %         % Update axes
        %             %         ax.XLim = datenum([t-seconds(15) t]);
        %             %         datetick('x','keeplimits');
        %             %         drawnow;
        %
        %
        %         end
        %
        %         continue_statement = true;
        
    elseif sequencetableData{1,j} == 'P' % Take a Picture
        
%         % Analyzing the RGB Values of the specified electrode
%         
%         electrode_number = sequencetableData{3,j};
%         
%         drop = ColorDroplet.createObj(handles,electrode_number);
%         
%         drop.displayColor(handles,electrode_number);
        
        % Saving a pciture of the color assay with the % color + time
        percentageColor = num2str(sequencetableData{2,j}) ; % 
        
        real_image = getsnapshot(handles.vid);
        
        image_filename = strcat(percentageColor,'%Y','_color_image.jpg');
        
        image_figure = figure('Name',image_filename);
        imshow(real_image);
        
        sendmail('philippe.vo.matlab@gmail.com' , 'Color Assay', strcat('Yellow: ',percentageColor,'%',' || ','Status: ','Done')); % Send Email
        
        saveas(image_figure,image_filename);
        
        continue_statement = true;
        
    elseif sequencetableData{1,j} == 'R' % Take a Reference Picture
        
        take_reference_image(  );
        
        continue_statement = true;
        
    elseif sequencetableData{1,j} == 'C' % Take a Find Circle Picture
        
        light_angle_detection( handles )
        
        continue_statement = true;
        
    elseif sequencetableData{1,j} == 'F'
        
        if sequencetableData{2,j} == 'ON'
            
            set(handles.feedbackTogglebutton,'Value',1);
            
        elseif sequencetableData{2,j} == 'OFF'
            
            set(handles.feedbackTogglebutton,'Value',0);
            
        end
        
    else
        
        continue_statement = false;
        
    end
    
else
    
    continue_statement = false;
    
end



end

