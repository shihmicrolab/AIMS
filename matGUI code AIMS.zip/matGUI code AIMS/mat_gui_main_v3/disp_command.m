function [  ] = disp_command( handles,text )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

set(handles.commandText,'String',text);

end

