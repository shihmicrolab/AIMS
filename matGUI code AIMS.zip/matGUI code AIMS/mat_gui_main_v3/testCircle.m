%%
circleImage = imread('circle.jpg');
circleImage = rgb2gray(circleImage);
circleImage = imbinarize(circleImage);
%[centerdroplet1,radii1] = imfindcircles(circleImage,[10 50],'ObjectPolarity','dark','Sensitivity',0.97,'Method','TwoStage');
[centerdroplet2,radii2] = imfindcircles(circleImage,[50 100],'ObjectPolarity','dark','Sensitivity',0.97,'Method','TwoStage');
[centerdroplet3,radii3] = imfindcircles(circleImage,[100 150],'ObjectPolarity','dark','Sensitivity',0.97,'Method','TwoStage');
[centerdroplet4,radii4] = imfindcircles(circleImage,[150 200],'ObjectPolarity','dark','Sensitivity',0.97,'Method','TwoStage');

sd2 = size(centerdroplet2);
sd3 = size(centerdroplet3);
sd4 = size(centerdroplet4);

sd = sd2(1) + sd3(1) + sd4(1);

centerdroplet = zeros(sd,2);
radii = zeros(sd,1);

spaceCount = 0;


for i = 1:1:sd2(1)
    centerdroplet(spaceCount+i,1) = centerdroplet2(i,1);
    centerdroplet(spaceCount+i,2) = centerdroplet2(i,2);
    radii(spaceCount+i) = radii2(i);
   
    
end

spaceCount = sd2(1);

for i = 1:1:sd3(1)
    centerdroplet(spaceCount+i,1) = centerdroplet3(i,1);
    centerdroplet(spaceCount+i,2) = centerdroplet3(i,2);
    radii(spaceCount+i) = radii3(i);
    
end

spaceCount = sd2(1) + sd3(1);

for i = 1:1:sd4(1)
    centerdroplet(spaceCount+i,1) = centerdroplet4(i,1);
    centerdroplet(spaceCount+i,2) = centerdroplet4(i,2);
    radii(spaceCount+i) = radii4(i);
    
end


%%

imshow(circleImage);
h = imdistline;
viscircles(centerdroplet, radii,'Color','g');
imdistline
