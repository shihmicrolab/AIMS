function [ previous_electrode_number ] = previous_electrode_on( hObject,handles,counter,i,tempsequencetableData,mastertableData,sequencetableData )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

%% ELectrode who failed

if counter == 1
    
    previous_electrode_number = sequencetableData{i,counter};
    
else
    
    for step = 1:1:6
        for step_2 = 1:1:6
            if  tempsequencetableData{step,2} ~= 0
                
                electrode_number = tempsequencetableData{step,2} ;
                i_position = mastertableData(electrode_number,6);
                j_position = mastertableData(electrode_number,7);
                
                [ previousElectrode_candidate ] = previous_electrode_candidate(handles,i_position,j_position ) ;
                
                for step_1=1:1:4
                    
                    if previousElectrode_candidate(step_1) == sequencetableData{step_2,counter-1}
                        
                        actuate_electrode_multiple_on_noij( previousElectrode_candidate(step_1),handles,hObject );
                        
                    end
                    
                end
                
            end
            
        end
    end
    
end


end







