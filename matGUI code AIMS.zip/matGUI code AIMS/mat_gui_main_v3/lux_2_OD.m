function [ od_value ] = lux_2_OD( blank_lux_value,lux_value )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

od_value = log10(blank_lux_value / lux_value) / 0.028 ;

end

