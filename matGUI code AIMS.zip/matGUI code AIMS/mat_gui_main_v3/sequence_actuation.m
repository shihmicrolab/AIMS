function [ ] = sequence_actuation( hObject, handles )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

if get(handles.sequenceactuationRadiobutton,'Value') == 1
    
    disp_command(handles, 'Sequencing Activated');
    
    %Temporary sequence Table

    tempsequencetableData = get(handles.tempsequenceTable,'Data');
    
    % Getting info on Row increment Value and incrementing it for use
    
    % No more than 6 on at the same time
    
    handles = guidata(gcbo);
        
    if handles.tempsequenceRowincrement >= 20
        
        errordlg('Maximum of electrodes ON at same time is 20','Error');
        
        msg = 'Maximum of electrodes ON at same time is 20';
        
        error(msg);
        
    end
    
    
    
    handles.tempsequenceRowincrement = handles.tempsequenceRowincrement + 1 ;
    
    guidata(gcbo,handles);
    
    % Modifying the data in the Table to the buttons number
    
    tempsequencetableData {handles.tempsequenceRowincrement,1} = str2double(get(hObject,'String')) ;
    
    % Saving the data
    
    set(handles.tempsequenceTable,'Data',tempsequencetableData);
    
    guidata(hObject,handles);
    
    % Setting the pusbutton to magenta
    
    set(hObject,'BackgroundColor','magenta');
     
end

end

