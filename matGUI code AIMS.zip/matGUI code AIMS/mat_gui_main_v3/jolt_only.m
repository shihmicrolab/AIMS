function [  ] = jolt_only( hObject,handles,increasedVoltage)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

%% Initializing
disp_command(handles,'RE-ACTUATION PHASE INITITATED');

set(handles.phaseButton,'BackgroundColor','cyan','String','RE-ACTUATION PHASE','Fontweight','bold');

mastertableData = get(handles.masterTable,'Data');
tempsequencetableData = get(handles.tempsequenceTable,'Data');
sequencetableData = get(handles.sequenceTable,'Data');

number_of_electrode_failed = 0;
j = 0;

for i = 1:1:104
    
    if mastertableData(i,4) == 1
        
        j = j + 1;
        number_of_electrode_failed = number_of_electrode_failed + 1;
        tempsequencetableData{j,2} = i;
        set(handles.tempsequenceTable,'Data',tempsequencetableData);
        
        % Setting those who are getting actuated (FOR the CHECKING PHASE LOOP)
        mastertableData (i,5) = 1;
        
    end
    
end

set(handles.masterTable,'Data',mastertableData);

%% Correction method

%Jolt intended electrode

voltage_control(handles,increasedVoltage);
set(handles.functionGvoltageEdittext,'String',num2str(increasedVoltage));

for i = 1:1:6
    
    if  tempsequencetableData{i,2} ~= 0
        
        electrode_number = tempsequencetableData{i,2} ;
        actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
        
    end
    
end

pause(str2double(get(handles.correctiontimeEdittext,'String')));

for i = 1:1:6
    
    if  tempsequencetableData{i,2} ~= 0
        
        electrode_number = tempsequencetableData{i,2} ;
        actuate_electrode_multiple_off_noij( electrode_number,handles );
        
    end
    
end

%% Re-initializing

for i = 1:1:6
    
    tempsequencetableData{i,2} = '';
    
end

set(handles.tempsequenceTable,'Data',tempsequencetableData);

for i = 1:1:104
    
    mastertableData(i,4) = 0;
    
end

set(handles.masterTable,'Data',mastertableData);
disp('RE-ACTUATION PHASE TERMINATED');
end

