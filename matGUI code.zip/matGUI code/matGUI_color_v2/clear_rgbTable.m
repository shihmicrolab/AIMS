function [  ] = clear_rgbTable( handles )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

rgbtableData = get(handles.rgbTable,'Data');

for i = 1:1:4
    for j = 1:1:3
        
        rgbtableData{i,j} = '';
        
    end
end

set(handles.rgbTable,'Data',rgbtableData);

end

