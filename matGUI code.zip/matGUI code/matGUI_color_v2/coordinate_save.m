function [  ] = coordinate_save( handles, hObject,row )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

%Getting information from the master table

coordinatetableData = get (handles.coordinateTable,'Data');

% the time

s =  get(hObject,'String');

my_struct = evalin('base',s);

% Getting the x & y coordinate

position_x = my_struct.Position(1);

position_y = my_struct.Position(2);

% Getting the acuation number to know where to store the x_y coordinate in
% the master Table

% Setting position x into the table

% Since we are getting the 'upper-left' corner -> we have to calculate the
% 'middle' -> Matlab pixel range (upper left = 1,1) (downards right = max,max)

% This might be inaccurate if the image is 'slanted' (ie. every electrode dont have same 'dimensions')

middle = str2double(get(handles.electrodeDimensionEText,'String'))/2;

coordinatetableData(row,1) = position_x + middle ;

coordinatetableData(row,2) = position_y + middle ;

set(handles.coordinateTable,'Data',coordinatetableData);

end

