function varargout = Color_Analysis(varargin)
% COLOR_ANALYSIS MATLAB code for Color_Analysis.fig
%      COLOR_ANALYSIS, by itself, creates a new COLOR_ANALYSIS or raises the existing
%      singleton*.
%
%      H = COLOR_ANALYSIS returns the handle to a new COLOR_ANALYSIS or the handle to
%      the existing singleton*.
%
%      COLOR_ANALYSIS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in COLOR_ANALYSIS.M with the given input arguments.
%
%      COLOR_ANALYSIS('Property','Value',...) creates a new COLOR_ANALYSIS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Color_Analysis_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Color_Analysis_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Color_Analysis

% Last Modified by GUIDE v2.5 27-Jul-2017 23:36:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @Color_Analysis_OpeningFcn, ...
    'gui_OutputFcn',  @Color_Analysis_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Color_Analysis is made visible.
function Color_Analysis_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Color_Analysis (see VARARGIN)

% Choose default command line output for Color_Analysis
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Color_Analysis wait for user response (see UIRESUME)
% uiwait(handles.figure1);

coordinatetableData = zeros(4,2) ;

set(handles.coordinateTable,'Data',coordinatetableData);

rgbtableData = cell(4,2) ;

set(handles.rgbTable,'Data',rgbtableData);

bluetableData = cell(10,2) ;

set(handles.blueTable,'Data',bluetableData);


% --- Outputs from this function are returned to the command line.
function varargout = Color_Analysis_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in loadImageButton.
function loadImageButton_Callback(hObject, eventdata, handles)
% hObject    handle to loadImageButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

prompt = {'Enter image name w/o extension'};
dlg_title = 'Image Loading';
num_lines = 1;
defaultans = {''};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

imageName = strcat(cell2mat(answer),'.png');
image = imread(imageName);

figure('Name',imageName);
imshow(image);
imshow(image, 'Parent', handles.image_axe);

set(handles.loadedImageNameSText,'String',imageName)

% --- Executes on button press in saveDataButton.
function saveDataButton_Callback(hObject, eventdata, handles)
% hObject    handle to saveDataButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Construct a questdlg with three options
choice = questdlg('Save Method ?', ...
    'Save Method?', ...
    'Save specific','Save all accuracy','Cancel','Cancel');
% Handle response
switch choice
    case 'Save specific'
        rgbtableData = cell2table(get(handles.rgbTable,'Data'));
        
        prompt = {'Enter Filename'};
        dlg_title = 'RGB Excel';
        num_lines = 1;
        defaultans = {''};
        answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
        
        fileName = cell2mat(answer);
        
        writetable(rgbtableData,fileName,'WriteVariableNames' ,true);
        
    case 'Save all accuracy'
        
        set(handles.zeroMinButton,'Value',0);
        set(handles.fortyMinButton,'Value',0);
        set(handles.eightyMinButton,'Value',0);
        set(handles.hundredtwentyMinButton,'Value',0);
        
        prompt = {'Enter date name w/o extension'};
        dlg_title = 'Image Loading';
        num_lines = 1;
        defaultans = {''};
        answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
        
        accuracyValue = 4; % 25 % ONLY
        
        %% Water
        
        imageName = strcat (cell2mat(answer),'water','.png');
        image = imread(imageName);
        figure('Name',imageName);
        imshow(image);
        imshow(image, 'Parent', handles.image_axe);
        
        set(handles.loadedImageNameSText,'String',imageName)
        
        set(handles.zeroMinButton,'Value',1);
        set(handles.fortyMinButton,'Value',1);
        set(handles.eightyMinButton,'Value',1);
        set(handles.hundredtwentyMinButton,'Value',1);
        
        accuracy_box( handles,hObject,accuracyValue);
        
        rgbtableDatacell = cell2table(get(handles.rgbTable,'Data'));
        
        fileName = strcat(get(handles.loadedImageNameSText,'String'),'_RGB','.xlsx');
        
        writetable(rgbtableDatacell,fileName,'WriteVariableNames' ,true);
        
        disp('Done Saving to Excel');
        
        clear_rgbTable( handles );
        
        set(handles.zeroMinButton,'Value',0);
        set(handles.fortyMinButton,'Value',0);
        set(handles.eightyMinButton,'Value',0);
        set(handles.hundredtwentyMinButton,'Value',0);
        
        %% Color
        
        for img_step =0:40:120
            
            switch img_step
                
                case 0
                    set(handles.zeroMinButton,'Value',1);
                case 40
                    set(handles.fortyMinButton,'Value',1);
                case 80
                    set(handles.eightyMinButton,'Value',1);
                case 120
                    set(handles.hundredtwentyMinButton,'Value',1);
                    
            end
            
            imageName = strcat (cell2mat(answer),num2str(img_step),'M.png');
            image = imread(imageName);
            figure('Name',imageName);
            imshow(image);
            imshow(image, 'Parent', handles.image_axe);
            
            set(handles.loadedImageNameSText,'String',imageName)
            
            value0 = get(handles.zeroMinButton,'Value');
            value40 = get(handles.fortyMinButton,'Value');
            value80 = get(handles.eightyMinButton,'Value');
            value120 = get(handles.hundredtwentyMinButton,'Value');
            
            checkValueArray = zeros (1,4);
            
            checkValueArray(1,1) = value0;
            checkValueArray(1,2) = value40;
            checkValueArray(1,3) = value80;
            checkValueArray(1,4) = value120;
            
            
            
            for i = 1:1:4
                
                if checkValueArray(1,i) == 1
                    
                        accuracy_box( handles,hObject,accuracyValue);
                        
                end
                
            end
            
            rgbtableDatacell = cell2table(get(handles.rgbTable,'Data'));
            
            fileName = strcat(get(handles.loadedImageNameSText,'String'),'_RGB','.xlsx');
            
            writetable(rgbtableDatacell,fileName,'WriteVariableNames' ,true);
            
            disp('Done Saving to Excel');
            
            set(handles.zeroMinButton,'Value',0);
            set(handles.fortyMinButton,'Value',0);
            set(handles.eightyMinButton,'Value',0);
            set(handles.hundredtwentyMinButton,'Value',0);
            
            %clear_rgbTable( handles );
            
        end
        
        clear_rgbTable( handles );
        
    case 'Cancel'
        disp('canceled');
        
end



% --- Executes on slider movement.
function accuracySlider_Callback(hObject, eventdata, handles)
% hObject    handle to accuracySlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

set(hObject,'Min',0);
set(hObject,'Max',10);
accuracyValue = round(get(hObject,'Value'));
disp(accuracyValue);
set(hObject,'Value',accuracyValue);

set(handles.accuracyNumberSText,'String',accuracyValue);

accuracy_box( handles,hObject,accuracyValue);

% --- Executes during object creation, after setting all properties.
function accuracySlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to accuracySlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in clearCoordinateTableButton.
function clearCoordinateTableButton_Callback(hObject, eventdata, handles)
% hObject    handle to clearCoordinateTableButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in zeroMinButton.
function zeroMinButton_Callback(hObject, eventdata, handles)
% hObject    handle to zeroMinButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

row = 1;
coordinate_save( handles, hObject,row );
% --- Executes on button press in fortyMinButton.
function fortyMinButton_Callback(hObject, eventdata, handles)
% hObject    handle to fortyMinButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

row = 2;
coordinate_save( handles, hObject,row );
% --- Executes on button press in eightyMinButton.
function eightyMinButton_Callback(hObject, eventdata, handles)
% hObject    handle to eightyMinButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

row = 3;
coordinate_save( handles, hObject,row );
% --- Executes on button press in hundredtwentyMinButton.
function hundredtwentyMinButton_Callback(hObject, eventdata, handles)
% hObject    handle to hundredtwentyMinButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

row = 4;
coordinate_save( handles, hObject,row );
% --- Executes on button press in clearRgbTable.
function clearRgbTable_Callback(hObject, eventdata, handles)
% hObject    handle to clearRgbTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

rgbtableData = get(handles.rgbTable,'Data');

for i = 1:1:4
    for j = 1:1:3
        
        rgbtableData{i,j} = '';
        
    end
end

set(handles.rgbTable,'Data',rgbtableData);

function electrodeDimensionEText_Callback(hObject, eventdata, handles)
% hObject    handle to electrodeDimensionEText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of electrodeDimensionEText as text
%        str2double(get(hObject,'String')) returns contents of electrodeDimensionEText as a double


% --- Executes during object creation, after setting all properties.
function electrodeDimensionEText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to electrodeDimensionEText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in dispMiddleCoordinateButton.
function dispMiddleCoordinateButton_Callback(hObject, eventdata, handles)
% hObject    handle to dispMiddleCoordinateButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

coordinatetableData = get(handles.coordinateTable,'Data');

for i = 1:1:4
    
    x_position = coordinatetableData(i,1);
    y_position = coordinatetableData(i,2);
    
    if x_position == 0 || y_position == 0
        
        continue;
        
    end
    
    viscircles(handles.image_axe,[x_position y_position],1);
    
end


% --- Executes on button press in dispAccuracyBoxButton.
function dispAccuracyBoxButton_Callback(hObject, eventdata, handles)
% hObject    handle to dispAccuracyBoxButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --- Executes on button press in clearImageButton.
function clearImageButton_Callback(hObject, eventdata, handles)
% hObject    handle to clearImageButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

lineObj = findobj(handles.image_axe,'Type','line');

delete(lineObj);
