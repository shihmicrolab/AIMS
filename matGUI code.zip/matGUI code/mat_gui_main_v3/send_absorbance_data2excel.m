 function [  ] = send_absorbance_data2excel( handles,luxvaluesData )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

% Prompt that asks user for the name of their files
prompt = {'Lux File name (txt)','OD File name (excel)'};
dlg_title = 'Absorbance ';
num_lines = 1;
defaultans = {'name','name'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

lux_Filename = cell2mat(answer(1));

od_Filename = cell2mat(answer(2));

lux_Filename_send = strcat(lux_Filename,'.txt');

od_Filename_send = strcat(od_Filename,'.xlsx');

% Save All LUX Values to excel %

luxValuesFile = luxvaluesData;

% % FileName =['LUX_',datestr(now, 'dd-mm-yyyy HH:MM:SS'),'_.txt'];
% FileName =['LUX_',datestr(now, 'dd-mm-yyyy'),'_.txt'];

save(lux_Filename_send,'luxValuesFile','-ascii');
            
% Save All LUX Values to excel %


% Send Lux Values to Table %

 % Get absorbance table Data
            
            absorbancetableData = get(handles.absorbanceTable,'Data');
            
            % Get the lux Values
            
            luxValuesFile = luxvaluesData;
            
            % Init the average lux value to be sent to table
            
            summingLux = 0;
            
            % Init the position of the average lux value to be sent to
            % table
            
            averageLux_counter = 0;
            
            % Calculating the average for Lux and sending it to absorbance Table
            
            for i = 1:1:handles.numberReadings
                
                summingLux = luxValuesFile(i,1) +  summingLux;
                
                % Looking at when to stop and take the average
                
                if mod(i,handles.number2Average) == 0
                    
                    averageLux_counter = averageLux_counter + 1;
                    
                    averageLux_send = summingLux/handles.number2Average;
                    
                    absorbancetableData {averageLux_counter,1} = averageLux_send;
                    
                    % Convert it to OD
                      
                    absorbancetableData {averageLux_counter,2} = lux_2_OD( str2double(get(handles.blankluxEdittext,'String')),averageLux_send );
                    
                    % Reinit the average Lux value
                    
                    summingLux = 0;
                    
                end
                
            end
            
            % Set absorbance table Data
            
            set(handles.absorbanceTable,'Data',absorbancetableData);
            
% Send Lux Values to Table %


% Save Lux + OD to Excel %

% Get absorbance table Data
            
            absorbancetableData = get(handles.absorbanceTable,'Data');
           
%             %FileName =['OD_',datestr(now, 'ddd-mm-yyyy_HH:MM:SS'),'_.xlsx'];
%             FileName =['OD_',datestr(now, 'ddd-mm-yyyy'),'_.xlsx'];
            
           absorbancetableData_converted =  cell2table(absorbancetableData);
            
            writetable(absorbancetableData_converted,od_Filename_send);
            
            % Reinit the absorbance table
            
             for i = 1:1:handles.numberReadings
                 
                 absorbancetableData{i,1} = '';
                 absorbancetableData{i,2} = '';
                 
             end
             
              % Set absorbance table Data
            
            set(handles.absorbanceTable,'Data',absorbancetableData);
            
% Save Lux + OD to Excel %



end

