function [ breakstatement ] = cancel_sequence_flag( handles )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

% Checking if user press the cancel button

       cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');

        if cancelsequence_flag == 1

            disp_command(handles,'Cancelling Operation...');

            cancelsequence_flag = 0;

            set(handles.cancelsequenceButton,'UserData',cancelsequence_flag);

            breakstatement = 1;
            
        else
            
            breakstatement = 0;

        end
       
end


