function [  ] = actuate_electrode_multiple_on_noij( electrode_number,handles,hObject )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

if get(handles.testtoggleButton,'Value') == 0
    % Converting the numbers from (user input) to which max we are talking.
    
    address  = conversion_2_arduino_address( handles , electrode_number );
    actNum  = conversion_2_arduino_actNum(  electrode_number );
    
    writeRegister(address,actNum,1);
    disp(['Electrode = ',int2str(electrode_number), ' turned ON']);
    disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned ON']);
    
    % Coloring the electrodes (green)
    color_electrode_pad( electrode_number,'green',handles );
    
else
    
    % Converting the numbers from (user input) to which max we are talking.
    
    % address  = conversion_2_arduino_address( handles , electrode_number );
    % actNum  = conversion_2_arduino_actNum(  electrode_number );
    %
    % writeRegister(address,actNum,1);
    disp(['Electrode = ',int2str(electrode_number), ' turned ON']);
    disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned ON']);
    
    % Coloring the electrodes (green)
    color_electrode_pad( electrode_number,'green',handles );
    
    
end