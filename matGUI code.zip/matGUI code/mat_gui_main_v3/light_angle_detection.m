function [  ] = light_angle_detection( handles )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

prompt = {'Degree : ','Lux : '};
            dlg_title = 'Light & Angle';
            num_lines = 1;
            defaultans = {'',''};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            
            degree = cell2mat(answer(1));
            lux = cell2mat(answer(2));

%% Circle Detection

compare_image_C = rgb2gray(getsnapshot(handles.vid ));

difference_image_C = imabsdiff(handles.avg_reference_image,compare_image_C);

difference_image_binary_C = imbinarize(difference_image_C);

dropletRadiusMin = str2double(get(handles.dropletradiusEdittext,'String')) - 3;

dropletRadiusMax = str2double(get(handles.dropletradiusEdittext,'String')) + 3;

[centerdroplet, radii] = imfindcircles(difference_image_binary_C,[dropletRadiusMin dropletRadiusMax],'ObjectPolarity','bright','Sensitivity',0.97,'Method','TwoStage');

circle_figure = figure('Name','Circle');
imshow(difference_image_binary_C)
h = viscircles(centerdroplet,radii);

circle_filename = strcat(degree,'D',lux,'L','_circle.jpg');

saveas(circle_figure,circle_filename);

%% Blob Detection

compare_image_B = rgb2gray(getsnapshot(handles.vid ));

difference_image_B = imabsdiff(handles.avg_reference_image,compare_image_B);

difference_image_binary_B = imbinarize(difference_image_B);

obj.blobAnalyser = vision.BlobAnalysis('BoundingBoxOutputPort', true, ...
    'AreaOutputPort', true, 'CentroidOutputPort', true, ...
    'MinimumBlobArea', 400);

[~, centerdroplet, bboxes] = obj.blobAnalyser.step(difference_image_binary_B);

difference_image_binary_B = im2uint8(difference_image_binary_B);
difference_image_binary_B = insertObjectAnnotation(difference_image_binary_B,'rectangle',bboxes,1);

blob_figure = figure('Name','Blob');
imshow(difference_image_binary_B);

blob_filename = strcat(degree,'D',lux,'L','_blob.jpg');

saveas(blob_figure,blob_filename);

%% Normal Screenshot

normal_pic = getsnapshot(handles.vid );
normal_figure = figure('Name','Normal');
imshow(normal_pic);
normal_filename = strcat(degree,'D',lux,'L','_normal.jpg');
saveas(normal_figure,normal_filename);
    


end

