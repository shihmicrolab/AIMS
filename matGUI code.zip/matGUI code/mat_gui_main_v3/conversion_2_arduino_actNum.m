function [ actNum] = conversion_2_arduino_actNum(  electrode_number )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

if electrode_number < 21 
    
    actNum = electrode_number + 43;
  
  elseif electrode_number > 20 && electrode_number < 41 
    
    actNum = electrode_number + 23;
  
    
  elseif electrode_number > 40 && electrode_number < 61 
    
    actNum = electrode_number+ 3;
  
    
  elseif electrode_number > 60 && electrode_number < 81
    
    actNum = electrode_number- 17;
  
    
  elseif electrode_number > 80 && electrode_number < 101
    
    actNum = electrode_number - 37;
  
  else
    
    actNum = electrode_number - 57;
  
end

end
