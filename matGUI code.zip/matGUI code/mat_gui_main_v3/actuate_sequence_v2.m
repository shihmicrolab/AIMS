function [  ] = actuate_sequence_v2( handles,hObject,step_sequence )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

set(handles.phaseButton,'BackgroundColor','green','String','ACUTATION PHASE','Fontweight','bold');

%%% ACTIVATE_SEQUENCE_CODE %%%

disp_command(handles,'Sequence Activated');

handles = guidata(gcbo);

counter = 0 ;

j = 0;

% Getting information from the sequence table
sequencetableData = get(handles.sequenceTable,'Data');

while counter ~= step_sequence %+ 1
    
    counter = counter + 1 ;
    
    j = j + 1;
    
    % Setting the increment string to "activated" collumn
    
    set(handles.sequencecollumnincrementText,'String',int2str(j));
    
    handles = guidata(gcbo);
    
    % Checking if user press the cancel button
    
    cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');

        if cancelsequence_flag == 1

           break
     
        end
    
    % Read the value of table and actuate the electrode
    
    for i = 1:1:6
        
        if isempty(sequencetableData{i,j}) == 1
            
            continue
            
        end
        
        % Getting absorbance Value
        
%         if set_absorbance_value_temp_array( handles,i,j,sequencetableData ) == 1
%             
%             continue
%             
%         end
        
        %Turning electrode ON
        
        electrode_number = sequencetableData{i,j};
        
        actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
        
    end
    
    
    pause(handles.time_electrode);
    
    
    for i = 1:1:6
        
        if isempty(sequencetableData{i,j}) == 1
            
            continue
            
        end
        
%         if sequencetableData{i,j} == 'A'
%             
%             continue
%             
%         end
        
        %Turning electrode OFF
        
        electrode_number = sequencetableData{i,j};
        
        actuate_electrode_multiple_off_noij( electrode_number,handles );
        
    end
    
end


% Saving Absorbance Values into Excel Files

% if get(handles.absorbanceTogglebutton,'Value') == 1
%     
%     handles.luxvaluesData =  luxvaluesData;
%     
%     guidata(hObject,handles);
%     
%     send_absorbance_data2excel( handles,luxvaluesData );
%     
% end


% Display that sequence is done

disp_command(handles,'Sequence Terminated');

% Setting the increment text back to 0

set(handles.sequencecollumnincrementText,'String','0');

% Set phase state

set(handles.phaseButton,'BackgroundColor','white','String','STAND-BY','Fontweight','bold');

end

