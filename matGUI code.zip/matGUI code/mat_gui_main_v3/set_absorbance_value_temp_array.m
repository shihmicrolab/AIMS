function [ continuestatement ] = set_absorbance_value_temp_array( handles,i,j,sequencetableData )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

% Getting absorbance Value

if sequencetableData{i,j} == 'A'
    
    absorbancevalue_Counter = absorbancevalue_Counter + 1;
    
    absorbanceValue = get_absorbance_value(handles);
    
    %absorbanceValue = absorbanceValue + 1  ;
    %testing purposes ^^
    
    absorbance_value_text = strcat('Absorbance Value: ',int2str(absorbanceValue));
    
    disp_command(handles,absorbance_value_text);
    
    luxvaluesData(absorbancevalue_Counter,1) = absorbanceValue;
    
    
    counter4time = counter4time + 1 ;
    
    % Input the time it was recorded
    
    if mod(counter4time,handles.number2Average) == 0
        
        time_counter = time_counter + 1;
        
        absorbancetableData {time_counter,3} = toc;
        
        set(handles.absorbanceTable,'Data',absorbancetableData);
        
    end
    
    continuestatement = 1;
    
else
    
    continuestatement = 0;
    
end


end
