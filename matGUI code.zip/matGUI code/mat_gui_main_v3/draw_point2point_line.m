function [ lineObj,lineObj1 ] = draw_point2point_line(handles, pnt1, pnt2 )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

% assuming pnt 1 and pnt 2 are arrays of x and y coordinates

x = [pnt1(1) pnt2(1)];
y = [pnt1(2) pnt2(2)];

lineObj = line (handles.previewvideoAxe,x,y,'Color','blue','LineWidth',2);
lineObj1 = line (handles.previewvideobinaryAxe,x,y,'Color','blue','LineWidth',2);

end

