function varargout = standardGUIv2(varargin)
% STANDARDGUIV2 MATLAB code for standardGUIv2.fig
%      STANDARDGUIV2, by itself, creates a new STANDARDGUIV2 or raises the existing
%      singleton*.
%
%      H = STANDARDGUIV2 returns the handle to a new STANDARDGUIV2 or the handle to
%      the existing singleton*.
%
%      STANDARDGUIV2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STANDARDGUIV2.M with the given input arguments.
%
%      STANDARDGUIV2('Property','Value',...) creates a new STANDARDGUIV2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before standardGUIv2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to standardGUIv2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help standardGUIv2

% Last Modified by GUIDE v2.5 08-Jul-2017 18:36:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @standardGUIv2_OpeningFcn, ...
    'gui_OutputFcn',  @standardGUIv2_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before standardGUIv2 is made visible.
function standardGUIv2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to standardGUIv2 (see VARARGIN)

% Choose default command line output for standardGUIv2
handles.output = hObject;

% Initialise tabs
handles.tabManager = TabManager( hObject );

guidata(hObject,handles);

% Properties added to the handles structure

temp_grid_flag = 0;

handles.temp_grid_flag = temp_grid_flag;

guidata(hObject,handles);

grid_flag = 0;

handles.grid_flag = grid_flag;

guidata(hObject,handles);

handles.time_electrode = str2double(get(handles.timeEdittext,'String'));

guidata(hObject,handles);

% Initializing Tables

% Temp Sequence Table

%tempsequencetableData = zeros(6,2) ;

tempsequencetableData = cell(20,2) ;

set(handles.tempsequenceTable,'Data',tempsequencetableData);

% Sequence Table

%sequencetableData = zeros(6,50) ;

sequencetableData = cell(20,500) ;

% Setting up the collumn width for the sequence table

sequenceCollumnwidth = cell(1,500);

for i = 1:1:500
    
    sequenceCollumnwidth{1,i} = 25;
    
end

set(handles.sequenceTable,'ColumnWidth',sequenceCollumnwidth);


set(handles.sequenceTable,'Data',sequencetableData);

% Sequencer Table

%sequencertableData = zeros(6,50) ;

sequencertableData = cell(6,50) ;


set(handles.sequencerTable,'Data',sequencertableData);

% Master Table

mastertableData = zeros(104,8) ;

set(handles.masterTable,'Data',mastertableData);

% Absorbance Table

absorbancetableData = cell(120,3) ;

set(handles.absorbanceTable,'Data',absorbancetableData);

% Reactuation Table

reactuationtableData = cell(51,14) ;

set(handles.reactuationTable,'Data',reactuationtableData);

% Table sequence row and collumn increment

tempsequenceRowincrement = 0;

handles.tempsequenceRowincrement = tempsequenceRowincrement;

guidata(hObject,handles);

sequenceCollumnincrement = 0;

handles.sequenceCollumnincrement = sequenceCollumnincrement;

guidata(hObject,handles);

% Init the canselsequence flag

cancelsequence_flag = 0;

set(handles.cancelsequenceButton,'UserData',cancelsequence_flag);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes standardGUIv2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% Messages to User (Updates and what not)
updates = 'Absorbance Connection -> Mac / Fix Mathieu value offset / add a waitbar';

h = msgbox({'Updates :' updates});



% --- Outputs from this function are returned to the command line.
function varargout = standardGUIv2_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
% --------------------------------------------------------------------

%SETTING UP GUI

% --------------------------------------------------------------------
function arduinoMenu_Callback(hObject, eventdata, handles)
% hObject    handle to arduinoMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function arduinoconnectButton_Callback(hObject, eventdata, handles)
% hObject    handle to arduinoconnectButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

disp_command( handles,'Connecting Arduino...' );

% Prompt that asks user for the com of the arduino
prompt = {'COM #'};
dlg_title = 'Setting up Arduino ';
num_lines = 1;
defaultans = {'0'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

answer_str = cell2mat(answer);

com_number = strcat('COM',answer_str) ; % PC
%com_number = '/dev/cu.usbmodem1411'; % Mac

disp_command( handles,com_number );

arduino_1 = arduino(com_number,'Uno','Libraries','I2C');

% Saving the arduino_1 (automation) to the handles structure

handles.arduino_1 = arduino_1 ;

guidata(hObject,handles);

% Scanning for the devices that will be addressed
addrs = scanI2CBus(arduino_1);

% Displaying to the command text
disp_command(handles,addrs);

max_1 = i2cdev(arduino_1,'0x40');
max_2 = i2cdev(arduino_1,'0x41');
max_3 = i2cdev(arduino_1,'0x42');
max_4 = i2cdev(arduino_1,'0x43');
max_5 = i2cdev(arduino_1,'0x44');
max_6 = i2cdev(arduino_1,'0x45');

% saving the max_# to be used as address when actuating
% electrodes

handles.max_1 = max_1;
handles.max_2 = max_2;
handles.max_3 = max_3;
handles.max_4 = max_4;
handles.max_5 = max_5;
handles.max_6 = max_6;

guidata(hObject,handles);

% Initialize the maxs
init_max_I2C( max_1 )
init_max_I2C( max_2 )
init_max_I2C( max_3 )
init_max_I2C( max_4 )
init_max_I2C( max_5 )
init_max_I2C( max_6 )

disp_command( handles,'Done Connecting Arduino' );


% --------------------------------------------------------------------
function closeMenu_Callback(hObject, eventdata, handles)
% hObject    handle to closeMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function terminatemenuButton_Callback(hObject, eventdata, handles)
% hObject    handle to terminatemenuButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

for i = 1:1:104
    
    electrode_number = i ;
    
    address  = conversion_2_arduino_address( handles , electrode_number ) ;
    actNum  = conversion_2_arduino_actNum(  electrode_number ) ;
    
    writeRegister(address,actNum,0) ;
    
    disp(['Electrode = ',int2str(electrode_number), ' turned OFF']);
    %disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned OFF']);
    
end

%fclose(handles.arduino_absorbance);
disp_command(handles,'Disconnecting Function Generator...');

disconnect(handles.myFGen );
clear myFgen;

disp_command(handles,'Done Disconnecting Function Generator');
clear all
clc
close all force


% --------------------------------------------------------------------
function uyeMenu_Callback(hObject, eventdata, handles)
% hObject    handle to uyeMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function ueyeconnectButton_Callback(hObject, eventdata, handles)
% hObject    handle to ueyeconnectButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

disp_command(handles,'Connecting uEye ...');

imaqhwinfo

info = imaqhwinfo('winvideo')

%dev_info = imaqhwinfo('winvideo',1)

vid = videoinput('winvideo',1,'RGB32_1280x1024') ;
%vid = videoinput('winvideo',1,'RGB32_2048x1536') ;

src = getselectedsource(vid);

src.HorizontalFlip = 'on';

handles.vid = vid;

guidata(hObject,handles);

vidRes = vid.VideoResolution;
nBands = vid.NumberOfBands;

axes(handles.previewvideoAxe);
hImage = image( zeros(vidRes(2), vidRes(1), nBands), 'Parent', handles.previewvideoAxe);

% Display the video data in your GUI.

preview(vid, hImage);

disp_command(handles,'Done Connecting uEye ...');


% --- Executes on button press in eastereggButton.
function eastereggButton_Callback(hObject, eventdata, handles)
% hObject    handle to eastereggButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

disp_command (handles,'This GUI was heavily inspired by the GUI created by 3 students ( Meko , Kaleem , Abtin ) in the summer of 2016 ( Nam was here :) )');

% --------------------------------------------------------------------
function newgridTool_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to newgridTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.realtimeRadiobutton,'Enable','Off');

set(handles.sequenceactuationRadiobutton,'Enable','Off');

warndlg('Kindly save your grid before using it');

% If doing other iterations of "New grid" -> to clear the "electrode"
% buttongroup

% If the user opened a grid, but then wants to make a new one
if handles.grid_flag >= 1
    
    choice = questdlg('Do you want to make a "New Grid"', ...
        'Grid', ...
        'Yes','No','No');
    
    switch choice
        
        case 'Yes'
            delete(handles.Electrode_pad);
        case 'No'
            msg = 'Error: Executing Order 66. You have doomed all the Jedis and Anakin is joining the dark side.';
            error(msg)
            
    end
    
    
    
end

handles.temp_grid_flag = handles.temp_grid_flag + 1;

guidata(hObject,handles);

if handles.temp_grid_flag > 1
    
    delete(handles.Temp_electrode_pad);
    
end

% Creating a New Grid

prompt = {'Rows','Collumns'};
dlg_title = '# Electrodes ';
num_lines = 1;
defaultans = {'0','0'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

temp_grid_row = str2double(cell2mat(answer(1)));

temp_grid_collumn = str2double(cell2mat(answer(2)));

handles.temp_grid_row = temp_grid_row;

guidata(hObject,handles);

handles.temp_grid_collumn = temp_grid_collumn;

guidata(hObject,handles);

for i = 1:1:temp_grid_row
    for j = 1:1:temp_grid_collumn
        
        Temp_electrode_pad(i,j) = uicontrol('Style','Pushbutton','String','0',...
            'Parent',handles.gridButtongroup,'Units','normalized','Position',[1/(temp_grid_collumn+1)*j 1-i/(temp_grid_row+1) 1/(temp_grid_collumn+1) 1/(temp_grid_row+1)],...
            'BackgroundColor','white','Callback',{@electrode_functions,handles});
        
        % Saving the values from Grid to the handles structure
        % Able to access the grid values using -> handles.Temp_electrode_pad(i,j) .
        
        handles.Temp_electrode_pad = Temp_electrode_pad ;
        guidata(hObject,handles);
        
        
        
        % Saving the values from Grid to the handles structure
        
    end
    
end

% --- Executes on button press in numberingRadiobutton.
function numberingRadiobutton_Callback(hObject, eventdata, handles)
% hObject    handle to numberingRadiobutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of numberingRadiobutton


% --------------------------------------------------------------------
function savegridTool_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to savegridTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Ask user if they are saving a new grid or modifying their current one.

choice = questdlg('Are you saving a " New Grid " or modifying a "Current Grid" ?', ...
    'Saving Grid', ...
    'Save New Grid','Modify Current Grid','Cancel','Cancel');
% Handle response
switch choice
    case 'Save New Grid'
        
        disp_command(handles,'Saving New Grid');
        
        % Reading the Strings from the Temp_electrode_pad
        
        % Creating a matrix of cells
        
        grid_table  = cell(handles.temp_grid_row,handles.temp_grid_collumn) ;
        
        
        for i = 1:1:handles.temp_grid_row
            for j = 1:1:handles.temp_grid_collumn
                
                % have to convert the char/str to cell types
                grid_table(i,j) = cellstr(get(handles.Temp_electrode_pad(i,j),'String'));
                
            end
        end
        
        row_info = handles.temp_grid_row ;
        
        collumn_info = handles.temp_grid_collumn;
        
        % Saving data into a .mat file
        uisave({'grid_table','row_info','collumn_info'},'grid_');
        % ^ the variable have to be enclosed in '', or will give an error message
        
        % Deleting the pushbuttons to prevent using the "New Grid"
        
        delete(handles.Temp_electrode_pad);
        
        set(handles.realtimeRadiobutton,'Enable','On');
        
        set(handles.sequenceactuationRadiobutton,'Enable','On');
        
    case 'Modify Current Grid'
        
        disp_command(handles,'Modifying Current Grid');
        
        % Reading the Strings from the Electrode_pad
        
        % Creating a matrix of cells
        
        grid_table  = cell(handles.grid_row,handles.grid_collumn) ;
        
        
        for i = 1:1:handles.grid_row
            for j = 1:1:handles.grid_collumn
                
                % have to convert the char/str to cell types
                grid_table(i,j) = cellstr(get(handles.Electrode_pad(i,j),'String'));
                
            end
        end
        
        row_info = handles.grid_row ;
        
        collumn_info = handles.grid_collumn;
        
        % Saving data into a .mat file
        uisave({'grid_table','row_info','collumn_info'},'grid_');
        % ^ the variable have to be enclosed in '', or will give an error message
        
        set(handles.realtimeRadiobutton,'Enable','On');
        
        set(handles.sequenceactuationRadiobutton,'Enable','On');
        
        delete(handles.Electrode_pad);
        
    case 'Cancel'
        disp_command(handles,'Cancel');
        
end

% --------------------------------------------------------------------
function opengridTool_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to opengridTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if handles.temp_grid_flag >= 1
    
    choice = questdlg('Do you want to open a  "Grid"', ...
        'Grid', ...
        'Yes','No','No');
    
    switch choice
        
        case 'Yes'
            delete(handles.Temp_electrode_pad);
        case 'No'
            msg = 'Error: Executing Order 66. You have doomed all the Jedis and Anakin is joining the dark side.';
            error(msg)
            
    end
    
end


% Opening the grid file
uiopen('load');

% Getting information from the file (grid info)

grid_row = row_info;

grid_collumn = collumn_info;

% Saving the info into the gui handles structure

handles.grid_row = grid_row;

handles.grid_collumn = grid_collumn;

% The electrode number are stored in grid_table(i,j)
% however they are stored as cells

% Use breakpoint -> ie. debugging to be able to see the variable that are
% saved and opened in the workspace

% If doing other iterations of "Open grid" -> to clear the "electrode"
% buttongroup

guidata(hObject,handles);

handles.grid_flag = handles.grid_flag + 1;

guidata(hObject,handles);

if handles.grid_flag > 1
    
    delete(handles.Electrode_pad);
    
end

%%% Creating the buttons & Saving info to Master Table -> Actuation Numbers

mastertableData = get(handles.masterTable,'Data');

for i = 1:1:grid_row
    for j = 1:1:grid_collumn
        
        if cell2mat(grid_table(i,j)) == '0'
            
            Electrode_pad(i,j) = uicontrol('Style','Pushbutton','String',grid_table(i,j),...
                'Parent',handles.gridButtongroup,'Units','normalized','Position',[1/(grid_collumn+1)*j 1-i/(grid_row+1) 1/(grid_collumn+1) 1/(grid_row+1)],...
                'BackgroundColor','white','Enable','off','Visible','off','Userdata',2,'Callback',{@electrode_functions,handles});
            
            continue
            
        end
        
        Electrode_pad(i,j) = uicontrol('Style','Pushbutton','String',grid_table(i,j),...
            'Parent',handles.gridButtongroup,'Units','normalized','Position',[1/(grid_collumn+1)*j 1-i/(grid_row+1) 1/(grid_collumn+1) 1/(grid_row+1)],...
            'BackgroundColor','white','Userdata',2,'Callback',{@electrode_functions,handles});
        
        % Saving the values from Grid to the handles structure
        % Able to access the grid values using -> handles.Electrode_pad(i,j) .
        
        %mastertableData(str2double(cell2mat(grid_table(i,j))),1) = str2double(cell2mat(grid_table(i,j)));
        
        number_2_table = str2double(cell2mat(grid_table(i,j)));
        
        mastertableData(number_2_table,1) =  number_2_table;
        
        % Saving the position of the actuation number as a button alone.
        % So that we are able to know that actuation number # is button (*i,*j)
        
        mastertableData(number_2_table,6) = i;
        
        mastertableData(number_2_table,7) = j;
        
        
        
    end
end

set(handles.masterTable,'Data',mastertableData);

handles.Electrode_pad = Electrode_pad ;
guidata(hObject,handles);

%set(handles.masterTable,'Data',mastertableData);




function timeEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to timeEditbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of timeEditbox as text
%        str2double(get(hObject,'String')) returns contents of timeEditbox as a double

time_electrode = str2double(get(hObject,'String'));

if time_electrode > 5
    
    errordlg('Please do not exceed 5 seconds of ON time');
    time_electrode  = 0.5;
    
    set(hObject,'String',0.5);
    
elseif time_electrode < 0.05
    
    errordlg('Please do not go below 0.5 second of ON time');
    time_electrode  = 0.05;
    
    set(hObject,'String',0.05);
    
else
    
    set(hObject,'String',get(hObject,'String'));
    
end

handles.time_electrode = time_electrode;

guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function timeEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to timeEditbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key press with focus on figure1 and none of its controls.
function figure1_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.FIGURE)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)

% Looking and Saving the key pressed by the user

key_pressed = get(hObject,'CurrentKey');

handles.key_pressed = key_pressed;

guidata(hObject,handles);

% Looking if the key pressed is the "space" key

if handles.key_pressed == 'space'
    
    space_key_pressed_functions( handles,hObject );
    
end


% --- Executes on button press in activatesequenceButton.
function activatesequenceButton_Callback(hObject, eventdata, handles)
% hObject    handle to activatesequenceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%% Starting the real time clock %%%

tic;

%%% INIT %%%

% Flag for Feedback Reactuation (breaking out when its 100% fail)
break_all = 0;

% Checking if Absorbance option is requested

if get(handles.absorbanceTogglebutton,'Value') == 1
    
    luxvaluesData = handles.luxValues;
    
    absorbancevalue_Counter = 0;
    
    absorbanceValue = 0;
    
end

% Init -> Calculating the entire time ON -> electrodes for the sequence to be processed

totaltimeON = 0;

% Re-init the reactuation table

% Getting information from the reactuation table

reactuationtableData = get(handles.reactuationTable,'Data');

% Make them empty

for i = 1:1:51
    for j = 1:1:14
        reactuationtableData {i,j} = '';
    end
end

% Saving information to the Reacuation table

set(handles.reactuationTable,'Data',reactuationtableData);

% Getting information from the reactuation table to get values

reactuationtableData = get(handles.reactuationTable,'Data');

%

%%% INIT %%%

%%% ACTIVATE_SEQUENCE_CODE %%%

%%% If Feedback is OFF %%%

set(handles.phaseButton,'BackgroundColor','green','String','ACUTATION PHASE','Fontweight','bold');

if get(handles.feedbackTogglebutton,'Value') == 0
    
    disp_command(handles,'Sequence Activated');
    
    handles = guidata(gcbo);
    
    counter = 0 ;
    
    j = 0;
    
    % Getting information from the sequence table
    sequencetableData = get(handles.sequenceTable,'Data');
    
    while counter ~= handles.sequenceCollumnincrement %+ 1
        
        counter = counter + 1 ;
        
        j = j + 1;
        
        % Setting the increment string to "activated" collumn
        
        set(handles.sequencecollumnincrementText,'String',int2str(j));
        
        handles = guidata(gcbo);
        
        % Checking if user press the cancel button
        
        cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
        
        if cancelsequence_flag == 1
            
            disp_command(handles,'Cancelling Operation...');
            
            cancelsequence_flag = 0;
            
            set(handles.cancelsequenceButton,'UserData',cancelsequence_flag);
            
            break
            
        end
        
        % Read the value of table and actuate the electrode
        
        for i = 1:1:6
            
            if isempty(sequencetableData{i,j}) == 1
                
                continue
                
            end
            
            % Getting absorbance Value
            
            %             if sequencetableData{i,j} == 'A'
            %
            %                 absorbancevalue_Counter = absorbancevalue_Counter + 1;
            %
            %                % absorbanceValue = get_absorbance_value(handles);
            %
            %                absorbanceValue = absorbanceValue + 1  ;
            %
            %                 absorbance_value_text = strcat('Absorbance Value: ',int2str(absorbanceValue));
            %
            %                 disp_command(handles,absorbance_value_text);
            %
            %                 luxvaluesData(absorbancevalue_Counter,1) = absorbanceValue;
            %
            %                 continue
            %
            %             end
            
            electrode_number = sequencetableData{i,j};
            
            actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
            
        end
        
        pause(handles.time_electrode);
        
        for i = 1:1:6
            
            if isempty(sequencetableData{i,j}) == 1
                
                continue
                
            end
            
            %             if sequencetableData{i,j} == 'A'
            %
            %                 continue
            %
            %             end
            
            electrode_number = sequencetableData{i,j};
            
            actuate_electrode_multiple_off_noij( electrode_number,handles );
            
        end
        
        % Summing the time on
        
        timeON = handles.time_electrode;
        
        totaltimeON = totaltimeON +timeON;
        
    end
    
    %      % ADDED SAFETY: TURNING ALL ELECTRODES OFF
    %
    %      for i = 1:1:104
    %
    %          electrode_number = i ;
    %
    %          address  = conversion_2_arduino_address( handles , electrode_number ) ;
    %          actNum  = conversion_2_arduino_actNum(  electrode_number ) ;
    %
    %        writeRegister(address,actNum,0) ;
    %
    %          disp(['Electrode = ',int2str(electrode_number), ' turned OFF']);
    %          disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned OFF']);
    %
    %      end
    
    % Display that sequence is done
    
    disp_command(handles,'Sequence Terminated');
    
    % Setting the increment text back to 0
    
    set(handles.sequencecollumnincrementText,'String','0');
    
end

%%% If Feedback is ON %%%

if get(handles.feedbackTogglebutton,'Value') == 1
    
    %Getting info from master Table
    
    mastertableData = get(handles.masterTable,'Data');
    
    disp_command(handles,'Sequence Activated');
    
    handles = guidata(gcbo);
    
    counter = 0 ;
    
    j = 0;
    
    % Getting information from the sequence table
    
    sequencetableData = get(handles.sequenceTable,'Data');
    
    while counter ~= handles.sequenceCollumnincrement %+ 1
        
        counter = counter + 1 ;
        
        j = j + 1;
        
        % Setting the increment string to "activated" collumn
        
        set(handles.sequencecollumnincrementText,'String',int2str(j));
        
        handles = guidata(gcbo);
        
        % Checking if user press the cancel button
        
        cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
        
        if cancelsequence_flag == 1
            
            disp_command(handles,'Cancelling Operation...');
            
            cancelsequence_flag = 0;
            
            set(handles.cancelsequenceButton,'UserData',cancelsequence_flag);
            
            break
            
        end
        
        % Read the value of table and actuate the electrode
        
        for i = 1:1:6
            
            if isempty(sequencetableData{i,j}) == 1
                
                continue
                
            end
            
            electrode_number = sequencetableData{i,j};
            
            actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
            
            %Setting the Value in the master Table to " Actuated " -> so
            %that CHEKCING PHASE knows who to look at...
            
            mastertableData(electrode_number,5) = 1;
            
        end
        
        pause(handles.time_electrode);
        
        for i = 1:1:6
            
            if isempty(sequencetableData{i,j}) == 1
                
                continue
                
            end
            
            electrode_number = sequencetableData{i,j};
            
            actuate_electrode_multiple_off_noij( electrode_number,handles );
            
        end
        
        % Summing the time on
        
        timeON = handles.time_electrode;
        
        totaltimeON = totaltimeON +timeON;
        
        % Saving info to master table (WHICH ONE GOT ACTUATED (1st time))
        
        set(handles.masterTable,'Data',mastertableData);
        
        %%% CHECKING PHASE LOOP SHOULD BE HERE %%%
        
        % Reinit the numbers of Reactuations for one step (2, because in the table -> 1st is the 3 collumn)
        
        countNumReactuations = 2;
        
        % CHECKING PHASE LOOP
        reactuation_flag = 0;
        check_state = checking_phase( handles,counter,reactuation_flag,countNumReactuations );
        
        % Initializing votlage increment
        
        incrementedVoltage = str2double(get(handles.functionGbasevoltageEdittext,'String'));
        
        while check_state == false
            
            % Incrementing the time for electrode to STAY ON. (by 0.5 s each increment)
            
            % Putting a max time as safety measure
            
            if str2double(get(handles.functionGvoltageEdittext,'String')) > 4
                
                disp ('Voltage is more than 2.4 - Therefore we broke out')
                break_all = 1;
                break
                
            end
            
            % Checking if user press the cancel button
            
            cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
            
            if cancelsequence_flag == 1
                
                disp_command(handles,'Cancelling Operation...');
                
                break
                
            end
            
            handles.time_electrode = handles.time_electrode + 0.05 ;
            
            
            %Saving the time_electrode into handles
            
            guidata(hObject,handles);
            
            % Setting into the TIME BOX TEXT
            
            %set(handles.timeEdittext,'String',int2str(handles.time_electrode)) ;
            set(handles.timeEdittext,'String',num2str(handles.time_electrode)) ;
            
            % Incrementing Voltage for JOLT
            
            incrementedVoltage = incrementedVoltage + 0.1;
            
            % RE-ACTUATION PHASE
            
            %with the correction phase (single line )
            re_actuation_phase( hObject,handles,incrementedVoltage,j );
            %no correction phase
            % re_actuation_phase( hObject,handles,incrementedVoltage);
            
            
            % Summing the time on
            
            timeON = handles.time_electrode;
            
            totaltimeON = totaltimeON +timeON;
            
            %%% Saving Time info to reactuation table %%%
            
            stepNumber2reactuationtable = counter;
            
            %Indicator for numbers of reactuations for one step
            
            countNumReactuations = countNumReactuations + 1;
            
            % Putting the step that has reactuation
            
            reactuationtableData {stepNumber2reactuationtable,1} = stepNumber2reactuationtable;
            
            %Putting the Time that is ON
            
            reactuationtableData {stepNumber2reactuationtable,countNumReactuations} = timeON;
            
            %%% Saving Time info to reactuation table %%%
            
            % Pause here
            %pause(1);
            
            % Flag that we are reactuating
            
            reactuation_flag = 1;
            
            % CHECKING PHASE
            check_state = checking_phase( handles,counter, reactuation_flag,countNumReactuations );
            
            % Pause here
            %pause(1);
            
        end
        
        % Setting the Voltage back to base line
        
        voltage_control( handles,str2double(get(handles.functionGbasevoltageEdittext,'String'))) ;
        set(handles.functionGvoltageEdittext,'String',get(handles.functionGbasevoltageEdittext,'String'));
        
        % Re-initialize the tables (EXTRA SAFETY) (OPTIONAL)
        
        mastertableData = get(handles.masterTable,'Data');
        
        tempsequencetableData = get(handles.tempsequenceTable,'Data');
        
        for i = 1:1:104
            
            mastertableData(i,4) = 0;
            mastertableData(i,5) = 0;
            
        end
        
        for i = 1:1:6
            
            tempsequencetableData{i,2} = '';
            
        end
        
        set(handles.masterTable,'Data',mastertableData);
        
        set(handles.tempsequenceTable,'Data',tempsequencetableData);
        
        % Puts the time back to 1 (Incremented by the CHECK PHASE LOOP)
        
        handles.time_electrode = str2double(get(handles.basetimeEdittext,'String'));
        
        guidata(hObject,handles);
        
        set(handles.timeEdittext,'String',num2str(handles.time_electrode));
        
        disp_command(handles,'FEEDBACK DONE');
        
        %%% CHECKING PHASE LOOP SHOULD BE HERE %%%
        
        % If 100 % Fail -> break out all
        
        if break_all == 1
            
            break
            
        end
        
    end
    
end

%%% WHOLE Sequencing STOPS HERE

% Display that sequence is done

disp_command(handles,'Sequence Terminated');

% Setting the real time on information

realtimeon = toc;

set(handles.realtotaltimeonStatictext,'String',int2str(realtimeon));

% Setting the last step it was on

set(handles.laststeponStatictext,'String',int2str(j));

% Sending the same two above information to disp()

disp('Real Total Time of sequence : ');
disp(realtimeon);

disp('Last Step it was on: ');
disp(j);

% Setting the increment text back to 0

set(handles.sequencecollumnincrementText,'String','0');

% RE-INIT THE MASTERTABLE + TEMP SEQUENCE TABLE %

mastertableData = get(handles.masterTable,'Data');

tempsequencetableData = get(handles.tempsequenceTable,'Data');

for i = 1:1:104
    
    mastertableData(i,4) = 0 ;
    mastertableData(i,5) = 0 ;
    
end

for i = 1:1:6
    
    tempsequencetableData{i,2} = '';
    
end

set(handles.masterTable,'Data',mastertableData);

set(handles.tempsequenceTable,'Data',tempsequencetableData);

% RE-INIT THE MASTERTABLE + TEMP SEQUENCE TABLE %

%%%

%%% END %%%

% Sending information about the total time on

set(handles.totaltimeonStatictext,'String',num2str(totaltimeON));

% Set phase state

set(handles.phaseButton,'BackgroundColor','white','String','STAND-BY','Fontweight','bold');

if get(handles.absorbanceTogglebutton,'Value') == 1
    
    % Saving Absorbance Values into handles Structure
    
    handles.luxvaluesData =  luxvaluesData;
    
    guidata(hObject,handles);
    
end

% Saving information to the Reacuation table

set(handles.reactuationTable,'Data',reactuationtableData);

%ADDED SAFETY: TURNING ALL ELECTRODES OFF


%     for i = 1:1:104
%
%         electrode_number = i ;
%
%         address  = conversion_2_arduino_address( handles , electrode_number ) ;
%         actNum  = conversion_2_arduino_actNum(  electrode_number ) ;
%
%         writeRegister(address,actNum,0) ;
%
%         disp(['Electrode = ',int2str(electrode_number), ' turned OFF']);
%         disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned OFF']);
%
%     end


%%% END %%%

% --- Executes on button press in cancelsequenceButton.
function cancelsequenceButton_Callback(hObject, eventdata, handles)
% hObject    handle to cancelsequenceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cancelsequence_flag = 1;

set(hObject,'UserData',cancelsequence_flag);

%guidata(hObject,handles);

% --- Executes on button press in reinitsequenceButton.
function reinitsequenceButton_Callback(hObject, eventdata, handles)
% hObject    handle to reinitsequenceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Setting the increment text back to 0

set(handles.sequencecollumnincrementText,'String','0');

% Re-init the Collumn increment

handles = guidata(gcbo);

handles.sequenceCollumnincrement = 0;

guidata(gcbo,handles);

% Re-init the sequence table

% Getting information from the sequence table
sequencetableData = get(handles.sequenceTable,'Data');

for i = 1:1:20
    for j = 1:1:500
        
        sequencetableData{i,j} = '';
        
    end
end

set(handles.sequenceTable,'Data',sequencetableData);


% --- Executes on button press in emergencyshutdownButton.
function emergencyshutdownButton_Callback(hObject, eventdata, handles)
% hObject    handle to emergencyshutdownButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

disp_command(handles,'Emergency Shutdown ACTIVATED');

disp('Emergency Shutdown ACTIVATED');

for i = 1:1:104
    
    electrode_number = i ;
    
    address  = conversion_2_arduino_address( handles , electrode_number ) ;
    actNum  = conversion_2_arduino_actNum(  electrode_number ) ;
    
    writeRegister(address,actNum,0) ;
    
    disp(['Electrode = ',int2str(electrode_number), ' turned OFF']);
    %disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned OFF']);
    
end






% --------------------------------------------------------------------
function idpicTool_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to idpicTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Making a Figure
%figure('Name','ID Picture','NumberTitle','off')

%Taking a picture
id_image = rgb2gray(getsnapshot(handles.vid ));

%Making some markers to help visualize the 'grid'
mastertableData = get(handles.masterTable,'Data');

for i = 1:1:104
    
    if mastertableData(i,2) == 0 || mastertableData(i,3) == 0
        
        continue
        
    end
    
    marker_position_x = mastertableData(i,2);
    
    marker_position_y = mastertableData(i,3);
    
    insertMarker(id_image,[marker_position_x marker_position_y],'+','Size',5,'color','blue');
    
end

imshow(id_image,'Parent',handles.idpicAxe);

%Saving the picture to be used later
handles.id_image = id_image;

guidata(hObject,handles);


% --------------------------------------------------------------------
function referencepicTool_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to referencepicTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% handles = guidata(gcbo);
%
% %Taking a picture
% reference_image = rgb2gray(getsnapshot(handles.vid ));
%
% handles.reference_image = reference_image;
%
% guidata(gcbo,handles);
%
% %Showing the picture inside the axes
% imshow(handles.reference_image,'Parent',handles.referencepicAxe);
%
% figure('Name','Reference Image','NumberTitle','off');
%
% imshow(reference_image);

%% Calibration Reference Image

% Resoolution of camera = 1024x1280

handles = guidata(gcbo);

sum_reference_image = zeros(1024,1280);

avg_reference_image = zeros(1024,1280);

h = waitbar(0,'1','Name','Calibrating Reference Image');
steps = 1;
for step = 1:steps
    % computations take place here
    
    reference_image = im2double(rgb2gray(getsnapshot(handles.vid)));
    sum_reference_image = reference_image + sum_reference_image;
    
    waitbar(step/steps,h,strcat(int2str(step),'%'));
    pause(0.25);
end
close(h)

avg_reference_image = im2uint8(sum_reference_image / 1);

handles.avg_reference_image = avg_reference_image;

guidata(gcbo,handles);

%Showing the picture inside the axes
imshow(handles.avg_reference_image,'Parent',handles.referencepicAxe);

figure('Name','Average Reference Image','NumberTitle','off');

imshow(uint8(avg_reference_image));

figure('Name','Reference Image','NumberTitle','off');
imshow(reference_image);


% --------------------------------------------------------------------
function saveidTool_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to saveidTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

disp_command(handles,'Work in progress');

%saving_coordinates_masterTable( handles );

%creating_id_picture( handles,hObject );

% --- Executes on button press in feedbackTogglebutton.
function feedbackTogglebutton_Callback(hObject, eventdata, handles)
% hObject    handle to feedbackTogglebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of feedbackTogglebutton

feedbackTogglevalue = get(handles.feedbackTogglebutton,'Value');

switch feedbackTogglevalue
    
    case 0
        
        set(handles.feedbackTogglebutton,'String','Feedback OFF','ForegroundColor','red','Fontweight','bold');
        
    case 1
        
        set(handles.feedbackTogglebutton,'String','Feedback ON','ForegroundColor','green','Fontweight','bold');
        
end


% --- Executes on button press in phaseTogglebutton.
function phaseTogglebutton_Callback(hObject, eventdata, handles)
% hObject    handle to phaseTogglebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of phaseTogglebutton


% --------------------------------------------------------------------
function videorecordTool_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to videorecordTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

videorecordstate = get(handles.videorecordTool,'State');

switch videorecordstate
    
    case  'on'
        
        disp_command(handles,'Recording Video...')
        
        % Prompt that asks user for the com of the arduino
        prompt = {'Number of cycles'};
        dlg_title = 'Video length';
        num_lines = 1;
        defaultans = {'0'};
        answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
        
        videocycles = str2double(cell2mat(answer));
        
        %hFigure = findall(0,'Name','standardGUIv2');
        
        for i = 1:1:videocycles
            
            recordvideo(i) = getframe(standardGUIv2);
            
        end
        
        figure
        axes('Position',[0 0 1 1])
        movie(recordvideo,1)
        
        % Prompt that asks user for the com of the arduino
        prompt = {'video file name (add .avi) :'};
        dlg_title = 'Saving File ';
        num_lines = 1;
        defaultans = {'0'};
        answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
        
        videofileName = cell2mat(answer);
        
        v = VideoWriter(videofileName);
        %Controlling the framerate of the 'movie'
        v.FrameRate = 15;
        open(v)
        writeVideo(v,recordvideo)
        close(v)
        
        clear recordvideo
        % not sure if this ^ is working to delete the recordvideo...
        
        set(handles.videorecordTool,'State','Off')
        
    case  'off'
        
        disp_command(handles,'Not Recording Video...')
        
end


% --------------------------------------------------------------------
function stopvideorecordTool_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to stopvideorecordTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in clearmastertableButton.
function clearmastertableButton_Callback(hObject, eventdata, handles)
% hObject    handle to clearmastertableButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mastertableData = get(handles.masterTable,'Data') ;

for i = 1:1:104
    for j = 1:1:5
        
        mastertableData(i,j) = 0;
        
    end
end

set(handles.masterTable,'Data',mastertableData);


% --------------------------------------------------------------------
function differencepicTool_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to differencepicTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Delete circles

delete h

%Taking a picture
preview_compare_image = rgb2gray(getsnapshot(handles.vid ));

preview_difference_image = imabsdiff(handles.reference_image,preview_compare_image);

preview_difference_image_binary = imbinarize(preview_difference_image);

% Finding circles

% Getting the radius of Droplet from user and puttin a min and max for it

dropletRadiusMin = handles.dropletRadius - 3;

dropletRadiusMax = handles.dropletRadius + 3;

[previewCenterdroplet, previewRadii] = imfindcircles(preview_difference_image_binary,[dropletRadiusMin dropletRadiusMax],'ObjectPolarity','bright','Sensitivity',0.96,'Method','TwoStage');

% Showing the picture inside the axes with circles

imshow(preview_difference_image_binary,'Parent',handles.comparepicAxe);

h = viscircles(handles.comparepicAxe,previewCenterdroplet,previewRadii);


% Deleting centerdroplet and radii (not sure if we really need this here)

delete previewCenterdroplet

delete previewRadii


% --- Executes on button press in phaseButton.
function phaseButton_Callback(hObject, eventdata, handles)
% hObject    handle to phaseButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

previous_electrode( handles );


function ledbrightnessEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to ledbrightnessEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ledbrightnessEdittext as text
%        str2double(get(hObject,'String')) returns contents of ledbrightnessEdittext as a double

dimmer = str2double(get(hObject,'String'));

% LED is on pin 9 -> Arduino
writePWMDutyCycle (handles.arduino_1, 'D9', dimmer);


% --- Executes during object creation, after setting all properties.
function ledbrightnessEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ledbrightnessEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function arduinoconnectabsorbanceButton_Callback(hObject, eventdata, handles)
% hObject    handle to arduinoconnectabsorbanceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

disp('Connecting Arduino Absorbance...' );

% Prompt that asks user for the com of the arduino
prompt = {'COM #'};
dlg_title = 'Setting up Arduino Absorbance ';
num_lines = 1;
defaultans = {'0'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

answer_str = cell2mat(answer);

com_number = strcat('COM',answer_str) ;
%com_number = '/dev/cu.usbmodem1411'; % Mac

disp(com_number );

flag = 1;
% Initialize Serial object
%arduino_absorbance = serial('/dev/cu.usbmodem1411');
arduino_absorbance = serial(com_number);
set(arduino_absorbance,'DataBits',8);
set(arduino_absorbance,'StopBits',1);
set(arduino_absorbance,'BaudRate',9600);
set(arduino_absorbance,'Parity','none');
fopen(arduino_absorbance);
a = 'b';
while (a~='a')
    a=fread(arduino_absorbance,1,'uchar');
end
if (a=='a')
    disp('Serial read');
end
fprintf(arduino_absorbance,'%c','a');
%mbox = msgbox('Serial Communication setup');
%uiwait(mbox);
disp_command(handles,'Done Connecting Arduino Absorbance')
fscanf(arduino_absorbance,'%u');

% Saving the arduino_absorbance (absorbance) to the handles structure

handles.arduino_absorbance = arduino_absorbance ;

guidata(hObject,handles);

disp('Done Connecting Arduino Absorbance' );


% --- Executes on button press in getvalueluxButton.
function getvalueluxButton_Callback(hObject, eventdata, handles)
% hObject    handle to getvalueluxButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

disp_command(handles,'Getting Absorbance Value...');

luxValues = zeros(5);
avgLuxValue = 0;
sumLuxValue = 0;

for i =1:1:8
    
    fprintf(handles.arduino_absorbance,'T');
    
    fprintf(handles.arduino_absorbance,'R');
    
    luxValues(i) = fscanf(handles.arduino_absorbance,'%f');
    
    sumLuxValue =  sumLuxValue + luxValues(i);
    
    pause(0.25);
    
end

avgLuxValue = sumLuxValue / 8;

set(handles.luxreadingStatictext,'String',num2str(avgLuxValue));

disp(avgLuxValue);

disp_command(handles,'Done with Absorbance Value...');




% --------------------------------------------------------------------
function screenshotTool_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to screenshotTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Taking a picture
screenshot_image = getsnapshot(handles.vid );

figure('Name','Screenshot image','NumberTitle','off');

imshow(screenshot_image);

function electrodedimensionEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to electrodedimensionEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of electrodedimensionEdittext as text
%        str2double(get(hObject,'String')) returns contents of electrodedimensionEdittext as a double

electrodeDimension = str2double(get(hObject,'String'));

handles.electrodeDimension = electrodeDimension;

guidata(hObject,handles);



% --- Executes during object creation, after setting all properties.
function electrodedimensionEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to electrodedimensionEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dropletradiusEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to dropletradiusEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dropletradiusEdittext as text
%        str2double(get(hObject,'String')) returns contents of dropletradiusEdittext as a double

dropletRadius = str2double(get(hObject,'String'));

handles.dropletRadius = dropletRadius;

guidata(hObject,handles);



% --- Executes during object creation, after setting all properties.
function dropletradiusEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dropletradiusEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function screenshotgrayTool_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to screenshotgrayTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Taking a picture
screenshotgray_image = rgb2gray(getsnapshot(handles.vid ));

figure('Name','Screenshot image','NumberTitle','off');

imshow(screenshotgray_image);

d = imdistline;


% --- Executes on button press in editsequencetableTogglebutton.
function editsequencetableTogglebutton_Callback(hObject, eventdata, handles)
% hObject    handle to editsequencetableTogglebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of editsequencetableTogglebutton

editsequencetableState = get(hObject,'Value');

switch editsequencetableState
    
    case 0
        set(hObject,'ForegroundColor','black');
        set(hObject,'Fontweight','normal');
        set(handles.sequenceTable,'ColumnEditable', false);
        set(handles.tempsequenceTable,'ColumnEditable', false);
        
        
    case 1
        
        set(hObject,'ForegroundColor','green');
        set(hObject,'Fontweight','bold');
        set(handles.sequenceTable,'ColumnEditable', true);
        set(handles.tempsequenceTable,'ColumnEditable', true);
        
        
end


% --- Executes on button press in activatesequencefromButton.
function activatesequencefromButton_Callback(hObject, eventdata, handles)
% hObject    handle to activatesequencefromButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Checking if Absorbance option is requested

if get(handles.absorbanceTogglebutton,'Value') == 1
    
    luxvaluesData = handles.luxValues;
    
    absorbancevalue_Counter = 0;
    
end

%%% ACTIVATE_SEQUENCE_CODE %%%

% Checking if the end sequence number is smalled than the start one

% Getting information on when the sequence starts and when it finishes

startsequenceNumber = str2double(get(handles.startactivatesequenceEdittext,'String'));

endsequenceNumber = str2double(get(handles.endsequenceactivateEdittext,'String'));

% Checking if the end sequence number is smalled than the start one

if endsequenceNumber < startsequenceNumber
    
    set(handles.endsequenceactivateEdittext,'String',int2str( startsequenceNumber + 1 ));
    warndlg('End sequence number cannot be less than the Start sequence number','Warning');
    
    cancelsequence_flag = 1;
    
    set(handles.cancelsequenceButton,'UserData',cancelsequence_flag);
    
end

%%% If Feedback is OFF %%%

set(handles.phaseButton,'BackgroundColor','green','String','ACUTATION PHASE','Fontweight','bold');

if get(handles.feedbackTogglebutton,'Value') == 0
    
    disp_command(handles,'Sequence Activated');
    
    handles = guidata(gcbo);
    
    % Getting information from the sequence table
    sequencetableData = get(handles.sequenceTable,'Data');
    
    for  currentsequenceNumber = startsequenceNumber:1:endsequenceNumber
        
        % Setting the increment string to "activated" collumn
        
        set(handles.sequencecollumnincrementText,'String',int2str(currentsequenceNumber));
        
        handles = guidata(gcbo);
        
        % Checking if user press the cancel button
        
        cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
        
        if cancelsequence_flag == 1
            
            disp_command(handles,'Cancelling Operation...');
            
            cancelsequence_flag = 0;
            
            set(handles.cancelsequenceButton,'UserData',cancelsequence_flag);
            
            break
            
        end
        
        % Read the value of table and actuate the electrode
        
        for i = 1:1:6
            
            if isempty(sequencetableData{i,currentsequenceNumber}) == 1
                
                continue
                
            end
            
            % Getting absorbance Value
            
            if sequencetableData{i,currentsequenceNumber} == 'A'
                
                absorbancevalue_Counter = absorbancevalue_Counter + 1;
                
                % absorbanceValue = get_absorbance_value(handles);
                
                absorbanceValue = 101;
                
                absorbance_value_text = strcat('Absorbance Value: ',num2str(absorbanceValue));
                
                disp_command(handles,absorbance_value_text);
                
                luxvaluesData(absorbancevalue_Counter,1) = absorbanceValue;
                
                continue
                
            end
            
            electrode_number = sequencetableData{i,currentsequenceNumber};
            
            actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
            
        end
        
        pause(handles.time_electrode);
        
        for i = 1:1:6
            
            if isempty(sequencetableData{i,currentsequenceNumber}) == 1
                
                continue
                
            end
            
            if sequencetableData{i,currentsequenceNumber} == 'A'
                
                continue
                
            end
            
            electrode_number = sequencetableData{i,currentsequenceNumber};
            
            actuate_electrode_multiple_off_noij( electrode_number,handles );
            
        end
        
    end
    
    % ADDED SAFETY: TURNING ALL ELECTRODES OFF
    
    %     for i = 1:1:104
    %
    %         electrode_number = i ;
    %
    %         address  = conversion_2_arduino_address( handles , electrode_number ) ;
    %         actNum  = conversion_2_arduino_actNum(  electrode_number ) ;
    %
    %         writeRegister(address,actNum,0) ;
    %
    %         disp(['Electrode = ',int2str(electrode_number), ' turned OFF']);
    %         disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned OFF']);
    %
    %     end
    
    % Display that sequence is done
    
    disp_command(handles,'Sequence Terminated');
    
    % Setting the increment text back to 0
    
    set(handles.sequencecollumnincrementText,'String','0');
    
end

%%% If Feedback is ON %%%

if get(handles.feedbackTogglebutton,'Value') == 1
    
    %Getting info from master Table
    
    mastertableData = get(handles.masterTable,'Data');
    
    disp_command(handles,'Sequence Activated');
    
    handles = guidata(gcbo);
    
    % Getting information from the sequence table
    
    sequencetableData = get(handles.sequenceTable,'Data');
    
    for  currentsequenceNumber = startsequenceNumber:1:endsequenceNumber
        
        % Setting the increment string to "activated" collumn
        
        set(handles.sequencecollumnincrementText,'String',int2str(currentsequenceNumber));
        
        handles = guidata(gcbo);
        
        % Checking if user press the cancel button
        
        cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
        
        if cancelsequence_flag == 1
            
            disp_command(handles,'Cancelling Operation...');
            
            cancelsequence_flag = 0;
            
            set(handles.cancelsequenceButton,'UserData',cancelsequence_flag);
            
            break
            
        end
        
        % Read the value of table and actuate the electrode
        
        for i = 1:1:6
            
            if isempty(sequencetableData{i,currentsequenceNumber}) == 1
                
                continue
                
            end
            
            electrode_number = sequencetableData{i,currentsequenceNumber};
            
            actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
            
            %Setting the Value in the master Table to " Actuated " -> so
            %that CHEKCING PHASE knows who to look at...
            
            mastertableData(electrode_number,5) = 1;
            
        end
        
        pause(handles.time_electrode);
        
        for i = 1:1:6
            
            if isempty(sequencetableData{i,currentsequenceNumber}) == 1
                
                continue
                
            end
            
            electrode_number = sequencetableData{i,currentsequenceNumber};
            
            actuate_electrode_multiple_off_noij( electrode_number,handles );
            
        end
        
        % Saving info to master table (WHICH ONE GOT ACTUATED (1st time))
        
        set(handles.masterTable,'Data',mastertableData);
        
        %%% CHECKING PHASE LOOP SHOULD BE HERE %%%
        
        % CHECKING PHASE LOOP
        
        check_state = checking_phase( handles );
        
        while check_state == false
            
            % Incrementing the time for electrode to STAY ON. (by 0.5 s each increment)
            
            % Putting a max time as safety measure
            
            if handles.time_electrode > 6
                
                disp ('The time electrode is on is more than 6s - Therefore we broke out')
                break
                
            end
            
            % Checking if user press the cancel button
            
            cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
            
            if cancelsequence_flag == 1
                
                disp_command(handles,'Cancelling Operation...');
                
                break
                
            end
            
            handles.time_electrode = handles.time_electrode + 0.5 ;
            
            %Saving the time_electrode into handles
            
            guidata(hObject,handles);
            
            % Setting into the TIME BOX TEXT
            
            %set(handles.timeEdittext,'String',int2str(handles.time_electrode)) ;
            set(handles.timeEdittext,'String',num2str(handles.time_electrode)) ;
            
            % RE-ACTUATION PHASE
            re_actuation_phase( hObject,handles );
            
            % Pause here
            pause(1);
            
            % CHECKING PHASE
            check_state = checking_phase( handles );
            
            % Pause here
            pause(1);
            
        end
        
        % Re-initialize the tables (EXTRA SAFETY) (OPTIONAL)
        
        mastertableData = get(handles.masterTable,'Data');
        
        tempsequencetableData = get(handles.tempsequenceTable,'Data');
        
        for i = 1:1:104
            
            mastertableData(i,4) = 0;
            mastertableData(i,5) = 0;
            
        end
        
        for i = 1:1:6
            
            tempsequencetableData{i,2} = '';
            
        end
        
        set(handles.masterTable,'Data',mastertableData);
        
        set(handles.tempsequenceTable,'Data',tempsequencetableData);
        
        % Puts the time back to 1 (Incremented by the CHECK PHASE LOOP)
        
        handles.time_electrode = str2double(get(handles.basetimeEdittext,'String'));
        
        guidata(hObject,handles);
        
        set(handles.timeEdittext,'String',int2str(handles.time_electrode));
        
        disp_command(handles,'FEEDBACK DONE');
        
        %%% CHECKING PHASE LOOP SHOULD BE HERE %%%
        
    end
    
    %%% WHOLE Sequencing STOPS HERE
    
    %     % ADDED SAFETY: TURNING ALL ELECTRODES OFF
    %
    %
    %     for i = 1:1:104
    %
    %         electrode_number = i ;
    %
    %         address  = conversion_2_arduino_address( handles , electrode_number ) ;
    %         actNum  = conversion_2_arduino_actNum(  electrode_number ) ;
    %
    %         writeRegister(address,actNum,0) ;
    %
    %         disp(['Electrode = ',int2str(electrode_number), ' turned OFF']);
    %         disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned OFF']);
    %
    %     end
    
    
    
    % Display that sequence is done
    
    disp_command(handles,'Sequence Terminated');
    
    % Setting the increment text back to 0
    
    set(handles.sequencecollumnincrementText,'String','0');
    
    % RE-INIT THE MASTERTABLE + TEMP SEQUENCE TABLE %
    
    mastertableData = get(handles.masterTable,'Data');
    
    tempsequencetableData = get(handles.tempsequenceTable,'Data');
    
    for i = 1:1:104
        
        mastertableData(i,4) = 0 ;
        mastertableData(i,5) = 0 ;
        
    end
    
    for i = 1:1:6
        
        tempsequencetableData{i,2} = '';
        
    end
    
    set(handles.masterTable,'Data',mastertableData);
    
    set(handles.tempsequenceTable,'Data',tempsequencetableData);
    
    % RE-INIT THE MASTERTABLE + TEMP SEQUENCE TABLE %
    
    %%%
    
end

set(handles.phaseButton,'BackgroundColor','white','String','STAND-BY','Fontweight','bold');

if get(handles.absorbanceTogglebutton,'Value') == 1
    
    % Saving Absorbance Values into handles Structure
    
    handles.luxvaluesData =  luxvaluesData;
    
    guidata(hObject,handles);
    
end


function startactivatesequenceEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to startactivatesequenceEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startactivatesequenceEdittext as text
%        str2double(get(hObject,'String')) returns contents of startactivatesequenceEdittext as a double

if str2double(get(hObject,'String')) < 1
    
    set(hObject,'String','1');
    warndlg('Start sequence number cannot be less than 1','Warning');
    
end



% --- Executes during object creation, after setting all properties.
function startactivatesequenceEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startactivatesequenceEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function endsequenceactivateEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to endsequenceactivateEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of endsequenceactivateEdittext as text
%        str2double(get(hObject,'String')) returns contents of endsequenceactivateEdittext as a double

if str2double(get(hObject,'String')) <= str2double(get(handles.startactivatesequenceEdittext,'String'))
    
    set(hObject,'String',int2str(str2double(get(handles.startactivatesequenceEdittext,'String')) + 1 ));
    warndlg('End sequence number cannot be less than the Start sequence number','Warning');
    
end

% --- Executes during object creation, after setting all properties.
function endsequenceactivateEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to endsequenceactivateEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dispensingelectrodeEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to dispensingelectrodeEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dispensingelectrodeEdittext as text
%        str2double(get(hObject,'String')) returns contents of dispensingelectrodeEdittext as a double


% --- Executes during object creation, after setting all properties.
function dispensingelectrodeEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dispensingelectrodeEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in dispensingelectrodesavePushbutton.
function dispensingelectrodesavePushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to dispensingelectrodesavePushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

dispensing_electrode = str2double(get(handles.dispensingelectrodeEdittext,'String'));

mastertableData = get(handles.masterTable,'Data');

mastertableData(dispensing_electrode,8) = 1;

set(handles.masterTable,'Data',mastertableData);


%%%---------------------------------------------------------------------%%%

% Just for testing Pictures

%%%---------------------------------------------------------------------%%%


% --- Executes on button press in differencepicturePushbutton.
function differencepicturePushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to differencepicturePushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Taking a picture
screenshotgray_image = rgb2gray(getsnapshot(handles.vid ));

difference_screenshotgray_image = imabsdiff(screenshotgray_image,handles.avg_reference_image);

figure('Name','Difference Picture','NumberTitle','off');

imshow(difference_screenshotgray_image);

d = imdistline;


% --- Executes on button press in binarizedpicturePushbutton.
function binarizedpicturePushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to binarizedpicturePushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Taking a picture
screenshotgray_image = rgb2gray(getsnapshot(handles.vid ));

difference_screenshotgray_image = imabsdiff(screenshotgray_image,handles.avg_reference_image);

binarized_screenshotgray_image = imbinarize(difference_screenshotgray_image);

figure('Name','Binarized Picture','NumberTitle','off');

imshow(binarized_screenshotgray_image);

d = imdistline;


% --- Executes on button press in circleblobButton.
function circleblobButton_Callback(hObject, eventdata, handles)
% hObject    handle to circleblobButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

light_angle_detection( handles );

% --- Executes on button press in readabsorbanceButton.
function readabsorbanceButton_Callback(hObject, eventdata, handles)
% hObject    handle to readabsorbanceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

implement_absorbance_sequence(handles );


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in absorbancevalueListbox.
function absorbancevalueListbox_Callback(hObject, eventdata, handles)
% hObject    handle to absorbancevalueListbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns absorbancevalueListbox contents as cell array
%        contents{get(hObject,'Value')} returns selected item from absorbancevalueListbox



if strcmp(get(handles.figure1,'SelectionType'),'open')
    
    index_selected = get(handles.absorbancevalueListbox,'Value');
    file_list = get(handles.absorbancevalueListbox,'String');
    filename = file_list{index_selected};
    
    disp_command(handles,filename);
    
    switch filename
        
        case 'Absorbance Value Setup'
            
            prompt = {'# of readings','# to average'};
            dlg_title = 'Absorbance Value Setup ';
            num_lines = 1;
            defaultans = {'0','0'};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            
            numberReadings = str2double(cell2mat(answer(1)));
            
            number2Average = str2double(cell2mat(answer(2)));
            
            handles.numberReadings = numberReadings;
            
            handles.number2Average = number2Average;
            
            guidata(hObject,handles);
            
            % Creating arrays to store the values
            
            luxValues = zeros(numberReadings,1);
            
            handles.luxValues = luxValues;
            
            guidata(hObject,handles);
            
            
            
            
        case 'Save all Lux Values to File'
            
            luxValuesFile = handles.luxvaluesData;
            
            prompt = {'Save: '};
            dlg_title = 'Save Lux Values';
            num_lines = 1;
            defaultans = {'0'};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            
            answer_text = cell2mat(answer);
            
            save(answer_text,'luxValuesFile','-ascii');
            
            
            
        case 'Send Average Lux and OD'
            
            % Get absorbance table Data
            
            absorbancetableData = get(handles.absorbanceTable,'Data');
            
            % Get the lux Values
            
            luxValuesFile = handles.luxvaluesData;
            
            % Init the average lux value to be sent to table
            
            summingLux = 0;
            
            % Init the position of the average lux value to be sent to
            % table
            
            averageLux_counter = 0;
            
            % Calculating the average for Lux and sending it to absorbance Table
            
            for i = 1:1:handles.numberReadings
                
                summingLux = luxValuesFile(i,1) +  summingLux;
                
                % Looking at when to stop and take the average
                
                if mod(i,handles.number2Average) == 0
                    
                    averageLux_counter = averageLux_counter + 1;
                    
                    averageLux_send = summingLux/handles.number2Average;
                    
                    absorbancetableData {averageLux_counter,1} = averageLux_send;
                    
                    % Convert it to OD
                    
                    absorbancetableData {averageLux_counter,2} = lux_2_OD( str2double(get(handles.blankluxEdittext,'String')),averageLux_send );
                    
                    % Reinit the average Lux value
                    
                    summingLux = 0;
                    
                end
                
            end
            
            % Set absorbance table Data
            
            set(handles.absorbanceTable,'Data',absorbancetableData);
            
            
        case 'Save OD Values to File'
            
            % Get absorbance table Data
            
            absorbancetableData = get(handles.absorbanceTable,'Data');
            
            
            
            prompt = {'Save: '};
            dlg_title = 'Save Lux Values';
            num_lines = 1;
            defaultans = {'0'};
            answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
            
            answer_text = cell2mat(answer);
            
            absorbancetableData_converted =  cell2table(absorbancetableData);
            
            writetable(absorbancetableData_converted,answer_text);
            
            % Reinit the absorbance table
            
            for i = 1:1:handles.numberReadings
                
                absorbancetableData{i,1} = '';
                absorbancetableData{i,2} = '';
                
            end
            
            % Set absorbance table Data
            
            set(handles.absorbanceTable,'Data',absorbancetableData);
            
    end
    
end


% --- Executes during object creation, after setting all properties.
function absorbancevalueListbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to absorbancevalueListbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in absorbanceTogglebutton.
function absorbanceTogglebutton_Callback(hObject, eventdata, handles)
% hObject    handle to absorbanceTogglebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of absorbanceTogglebutton

switch get(hObject,'Value')
    
    case 0
        
        set(hObject,'ForegroundColor','black');
        
    case 1
        
        set(hObject,'ForegroundColor','green');
        
end



function blankluxEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to blankluxEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of blankluxEdittext as text
%        str2double(get(hObject,'String')) returns contents of blankluxEdittext as a double


% --- Executes during object creation, after setting all properties.
function blankluxEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to blankluxEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sequencetimeEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to sequencetimeEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sequencetimeEdittext as text
%        str2double(get(hObject,'String')) returns contents of sequencetimeEdittext as a double


% --- Executes during object creation, after setting all properties.
function sequencetimeEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sequencetimeEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in actuatesequencetimeButton.
function actuatesequencetimeButton_Callback(hObject, eventdata, handles)
% hObject    handle to actuatesequencetimeButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%WE AUTOMATICALLY SEND OD TO EXCEL WITH THIS ACTUATE SEQUENCE TIME BUTTON%

% Getting the Starting Time

tic;

sequenceTime = str2double(get(handles.sequencetimeEdittext,'String'));

% Getting information from the lux Table

luxtableData = get(handles.luxTable,'Data');

% Checking if Absorbance option is requested

if get(handles.absorbanceTogglebutton,'Value') == 1
    
    luxvaluesData = handles.luxValues;
    
    absorbancevalue_Counter = 0;
    
    % absorbanceValue = 0;
    
end

%%% Reinitialize the Absorbance Stuff

if get(handles.absorbanceTogglebutton,'Value') == 1
    
    luxValues = zeros(handles.numberReadings,1);
    
    luxvaluesData = luxValues;
    
    absorbancevalue_Counter = 0;
    
    counter4time = 0;
    
    time_counter = 0;
    
    %Getting information from absorbance table
    
    absorbancetableData = get(handles.absorbanceTable,'Data');
    
    % Re-init the sequence table
    
    for i = 1:1:120
        for j = 1:1:3
            
            absorbancetableData{i,j} = '';
            
        end
    end
    
    set(handles.absorbanceTable,'Data',absorbancetableData);
    
    % Figure for Live Graphing of OD value
    
    figure('Name','OD Live Graph');
    
    odLine = animatedline;
    ax = gca;
    ax.YGrid = 'on';
    ax.YLim = [0 3];
    
    startTime = datetime('now');
    
end

%%% If Feedback is OFF %%%

set(handles.phaseButton,'BackgroundColor','green','String','ACUTATION PHASE','Fontweight','bold');

if get(handles.feedbackTogglebutton,'Value') == 0
    
    %%% TIME DEPENDENT ACTUATION %%%
    
    while str2double(get(handles.sequencetimeEdittext,'String')) > toc
        
        timeNow = toc;
        
        timeRemaining = sequenceTime - timeNow;
        
        timeremainingText = strcat('Time Remaining : ',int2str(timeRemaining));
        
        disp(timeremainingText);
        
        % Checking if user press the cancel button
        
        cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
        
        if cancelsequence_flag == 1
            
            disp_command(handles,'Cancelling Operation...');
            
            cancelsequence_flag = 0;
            
            set(handles.cancelsequenceButton,'UserData',cancelsequence_flag);
            
            break
            
        end
        
        disp(toc);
        
        %%% ACTIVATE_SEQUENCE_CODE %%%
        
        
        disp_command(handles,'Sequence Activated');
        
        handles = guidata(gcbo);
        
        counter = 0 ;
        
        j = 0;
        
        % Getting information from the sequence table
        sequencetableData = get(handles.sequenceTable,'Data');
        
        while counter ~= handles.sequenceCollumnincrement %+ 1
            
            counter = counter + 1 ;
            
            j = j + 1;
            
            % Setting the increment string to "activated" collumn
            
            set(handles.sequencecollumnincrementText,'String',int2str(j));
            
            handles = guidata(gcbo);
            
            % Checking if user press the cancel button
            
            cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
            
            if cancelsequence_flag == 1
                
                disp_command(handles,'Cancelling Operation...');
                
                %                 cancelsequence_flag = 0;
                %
                %                 set(handles.cancelsequenceButton,'UserData',cancelsequence_flag);
                
                break
                
            end
            
            if ischar(sequencetableData{1,j}) == 1
            
            if sequencetableData{1,j} == 'T'
                
                pause(str2double(sequencetableData{2,j}));
                
                continue
                
            end
            
            if sequencetableData{1,j} == 'V' % Voltage Change
                
                voltage2send = str2double(sequencetableData{2,j});
                
                voltage_control( handles,voltage2send );
                
                continue
                
            end
            
            if sequencetableData{1,j} == 'AT' % Acutation Time Change
                
                actuation_time = str2double(sequencetableData{2,j});
                
                set(handles.timeEdittext,'String',num2str(actuation_time));
                
                continue
                
            end
            
            end
            
            % Read the value of table and actuate the electrode
            
            for i = 1:1:6
                
                if isempty(sequencetableData{i,j}) == 1
                    
                    continue
                    
                end
                
                %Getting blank Value
                
                if ischar(sequencetableData{1,j}) == 1
                    
                    if sequencetableData{i,j} == 'O'
                        
                        blankValue = get_absorbance_value(handles);
                        
                        set(handles.blankluxEdittext,'String',num2str(blankValue));
                        
                    end
                    
                    % Getting absorbance Value
                    
                    if sequencetableData{i,j} == 'A'
                        
                        % Absorbance Value -> is really just Lux (should be FIXED)
                        
                        absorbancevalue_Counter = absorbancevalue_Counter + 1;
                        
                        absorbanceValue = get_absorbance_value(handles);
                        %absorbanceValue = 150;
                        
                        luxtableData{absorbancevalue_Counter,1} = absorbanceValue;
                        luxtableData{absorbancevalue_Counter,2} = toc;
                        
                        set(handles.luxTable,'Data',luxtableData);
                        
                        absorbance_value_text = strcat('Absorbance Value: ',num2str(absorbanceValue));
                        
                        disp_command(handles,absorbance_value_text);
                        
                        luxvaluesData(absorbancevalue_Counter,1) = absorbanceValue;
                        
                        counter4time = counter4time + 1 ;
                        
                        % Input the time it was recorded
                        
                        if mod(counter4time,handles.number2Average) == 0
                            
                            time_counter = time_counter + 1;
                            
                            absorbancetableData {time_counter,3} = toc;
                            
                            set(handles.absorbanceTable,'Data',absorbancetableData);
                            
                            % Input the Lux and OD also
                            
                            summingLuxTemp = 0;
                            
                            for k = 0:1:handles.number2Average - 1
                                
                                summingLuxTemp = luxvaluesData(absorbancevalue_Counter - k,1) + summingLuxTemp;
                                
                            end
                            
                            % Average the Lux
                            
                            averageLuxTemp_send = summingLuxTemp/handles.number2Average;
                            
                            absorbancetableData {time_counter,1} = averageLuxTemp_send;
                            
                            % output the OD
                            
                            absorbancetableData {time_counter,2} = lux_2_OD( str2double(get(handles.blankluxEdittext,'String')),averageLuxTemp_send );
                            
                            set(handles.absorbanceTable,'Data',absorbancetableData);
                            
                            % Sending values to Live Graph
                            
                            % OD value to send
                            
                            odValueGraph = lux_2_OD( str2double(get(handles.blankluxEdittext,'String')),averageLuxTemp_send );
                            
                            % Get current time
                            t =  datetime('now') - startTime;
                            
                            % Add points to animation
                            addpoints(odLine,datenum(t),odValueGraph);
                            
                            % Update axes
                            ax.XLim = datenum([t-seconds(15) t]);
                            datetick('x','keeplimits');
                            drawnow;
                            
                            
                        end
                        
                        
                        continue
                        
                    end
                    
                end
                
                electrode_number = sequencetableData{i,j};
                
                actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
                
            end
            
                
            
            pause(str2double(get(handles.timeEdittext,'String')));
            
            for i = 1:1:6
                
                if isempty(sequencetableData{i,j}) == 1
                    
                    continue
                    
                end
                
                if sequencetableData{i,j} == 'A'
                    
                    continue
                    
                end
                
                electrode_number = sequencetableData{i,j};
                
                actuate_electrode_multiple_off_noij( electrode_number,handles );
                
            end
            
        end
        
        %     % ADDED SAFETY: TURNING ALL ELECTRODES OFF
        
        %     for i = 1:1:104
        %
        %         electrode_number = i ;
        %
        %         address  = conversion_2_arduino_address( handles , electrode_number ) ;
        %         actNum  = conversion_2_arduino_actNum(  electrode_number ) ;
        %
        %         writeRegister(address,actNum,0) ;
        %
        %         disp(['Electrode = ',int2str(electrode_number), ' turned OFF']);
        %         disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned OFF']);
        %
        %     end
        
        % Display that sequence is done
        
        disp_command(handles,'Sequence Terminated');
        
        % Setting the increment text back to 0
        
        set(handles.sequencecollumnincrementText,'String','0');
        
    end
    
    % Sending Lux Value to Excel & plotting the live graph
    
    if get(handles.absorbanceTogglebutton,'Value') == 1
        
        % Excel
        
        handles.luxvaluesData =  luxvaluesData;
        
        guidata(hObject,handles);
        
        send_absorbance_data2excel( handles,luxvaluesData );
        
        % Live Graph
        
        [timeLogs,tempLogs] = getpoints(odLine);
        timeSecs = (timeLogs-timeLogs(1))*24*3600;
        figure('Name','OD Plot');
        plot(timeSecs,tempLogs);
        xlabel('Elapsed time (sec)');
        ylabel('OD Value');
        
    end
    
    %%% If Feedback is ON %%%
    
end

%%% Time Dependent Actuation w/ Feedback %%%

if get(handles.feedbackTogglebutton,'Value') == 1
    
    while str2double(get(handles.sequencetimeEdittext,'String')) > toc
        
        %Getting info from master Table
        
        mastertableData = get(handles.masterTable,'Data');
        
        disp_command(handles,'Sequence Activated');
        
        handles = guidata(gcbo);
        
        counter = 0 ;
        
        j = 0;
        
        % Getting information from the sequence table
        
        sequencetableData = get(handles.sequenceTable,'Data');
        
        while counter ~= handles.sequenceCollumnincrement %+ 1
            
            counter = counter + 1 ;
            
            j = j + 1;
            
            % Setting the increment string to "activated" collumn
            
            set(handles.sequencecollumnincrementText,'String',int2str(j));
            
            handles = guidata(gcbo);
            
            % Checking if user press the cancel button
            
            cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
            
            if cancelsequence_flag == 1
                
                disp_command(handles,'Cancelling Operation...');
                
                cancelsequence_flag = 0;
                
                set(handles.cancelsequenceButton,'UserData',cancelsequence_flag);
                
                break
                
            end
            
            % Read the value of table and actuate the electrode
            
            for i = 1:1:6
                
                if isempty(sequencetableData{i,j}) == 1
                    
                    continue
                    
                end
                
                electrode_number = sequencetableData{i,j};
                
                actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
                
                %Setting the Value in the master Table to " Actuated " -> so
                %that CHEKCING PHASE knows who to look at...
                
                mastertableData(electrode_number,5) = 1;
                
            end
            
            pause(handles.time_electrode);
            
            for i = 1:1:6
                
                if isempty(sequencetableData{i,j}) == 1
                    
                    continue
                    
                end
                
                electrode_number = sequencetableData{i,j};
                
                actuate_electrode_multiple_off_noij( electrode_number,handles );
                
            end
            
            % Saving info to master table (WHICH ONE GOT ACTUATED (1st time))
            
            set(handles.masterTable,'Data',mastertableData);
            
            %%% CHECKING PHASE LOOP SHOULD BE HERE %%%
            
            % CHECKING PHASE LOOP
            
            check_state = checking_phase( handles );
            
            while check_state == false
                
                % Incrementing the time for electrode to STAY ON. (by 0.5 s each increment)
                
                % Putting a max time as safety measure
                
                if handles.time_electrode > 6
                    
                    disp ('The time electrode is on is more than 3s - Therefore we broke out')
                    break
                    
                end
                
                % Checking if user press the cancel button
                
                cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
                
                if cancelsequence_flag == 1
                    
                    disp_command(handles,'Cancelling Operation...');
                    
                    break
                    
                end
                
                handles.time_electrode = handles.time_electrode + 0.5 ;
                
                %Saving the time_electrode into handles
                
                guidata(hObject,handles);
                
                % Setting into the TIME BOX TEXT
                
                %set(handles.timeEdittext,'String',int2str(handles.time_electrode)) ;
                set(handles.timeEdittext,'String',num2str(handles.time_electrode)) ;
                
                % RE-ACTUATION PHASE
                re_actuation_phase( hObject,handles );
                
                % Pause here
                pause(1);
                
                % CHECKING PHASE
                check_state = checking_phase( handles );
                
                % Pause here
                pause(1);
                
            end
            
            % Re-initialize the tables (EXTRA SAFETY) (OPTIONAL)
            
            mastertableData = get(handles.masterTable,'Data');
            
            tempsequencetableData = get(handles.tempsequenceTable,'Data');
            
            for i = 1:1:104
                
                mastertableData(i,4) = 0;
                mastertableData(i,5) = 0;
                
            end
            
            for i = 1:1:6
                
                tempsequencetableData{i,2} = '';
                
            end
            
            set(handles.masterTable,'Data',mastertableData);
            
            set(handles.tempsequenceTable,'Data',tempsequencetableData);
            
            % Puts the time back to 1 (Incremented by the CHECK PHASE LOOP)
            
            handles.time_electrode = str2double(get(handles.basetimeEdittext,'String'));
            
            guidata(hObject,handles);
            
            set(handles.timeEdittext,'String',int2str(handles.time_electrode));
            
            disp_command(handles,'FEEDBACK DONE');
            
            %%% CHECKING PHASE LOOP SHOULD BE HERE %%%
            
        end
        
        %%% WHOLE Sequencing STOPS HERE
        
        % Display that sequence is done
        
        disp_command(handles,'Sequence Terminated');
        
        % Setting the increment text back to 0
        
        set(handles.sequencecollumnincrementText,'String','0');
        
        % RE-INIT THE MASTERTABLE + TEMP SEQUENCE TABLE %
        
        mastertableData = get(handles.masterTable,'Data');
        
        tempsequencetableData = get(handles.tempsequenceTable,'Data');
        
        for i = 1:1:104
            
            mastertableData(i,4) = 0 ;
            mastertableData(i,5) = 0 ;
            
        end
        
        for i = 1:1:6
            
            tempsequencetableData{i,2} = '';
            
        end
        
        set(handles.masterTable,'Data',mastertableData);
        
        set(handles.tempsequenceTable,'Data',tempsequencetableData);
        
        % RE-INIT THE MASTERTABLE + TEMP SEQUENCE TABLE %
        
        %%%
        
    end
    
end

set(handles.phaseButton,'BackgroundColor','white','String','STAND-BY','Fontweight','bold');

%% Saving and clearing the Lux table data

luxtableData_converted =  cell2table(luxtableData);

Filename = sprintf('lux_backup_%s.xlsx', datestr(now,'mm-dd-yyyy-HH-MM'));

writetable(luxtableData_converted,Filename);


% % Saving Absorbance Values into handles Structure
%
% if get(handles.absorbanceTogglebutton,'Value') == 1
%
% handles.luxvaluesData =  luxvaluesData;
%
% guidata(hObject,handles);
%
% send_absorbance_data2excel( handles,luxvaluesData );
%
% end

% % ADDED SAFETY: TURNING ALL ELECTRODES OFF
%
%
%     for i = 1:1:104
%
%         electrode_number = i ;
%
%         address  = conversion_2_arduino_address( handles , electrode_number ) ;
%         actNum  = conversion_2_arduino_actNum(  electrode_number ) ;
%
%         writeRegister(address,actNum,0) ;
%
%         disp(['Electrode = ',int2str(electrode_number), ' turned OFF']);
%         disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned OFF']);
%
%     end



function basetimeEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to basetimeEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of basetimeEdittext as text
%        str2double(get(hObject,'String')) returns contents of basetimeEdittext as a double


% --- Executes during object creation, after setting all properties.
function basetimeEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to basetimeEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sequencenameloadEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to sequencenameloadEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sequencenameloadEdittext as text
%        str2double(get(hObject,'String')) returns contents of sequencenameloadEdittext as a double


% --- Executes during object creation, after setting all properties.
function sequencenameloadEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sequencenameloadEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in savesequenceButton.
function savesequenceButton_Callback(hObject, eventdata, handles)
% hObject    handle to savesequenceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Getting the data from the sequence table to send 2 sequencer

sequencetableData = get(handles.sequenceTable, 'Data');

% Saving sequence table to workspace (.mat file)

prompt = {'Sequence name: '};
dlg_title = 'Save Sequence';
num_lines = 1;
defaultans = {'sequence_'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

filename = cell2mat(answer);

save(filename, 'sequencetableData');


function send2sequencersaveEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to send2sequencersaveEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of send2sequencersaveEdittext as text
%        str2double(get(hObject,'String')) returns contents of send2sequencersaveEdittext as a double


% --- Executes during object creation, after setting all properties.
function send2sequencersaveEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to send2sequencersaveEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in activatesequencerButton.
function activatesequencerButton_Callback(hObject, eventdata, handles)
% hObject    handle to activatesequencerButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get sequencer table data
sequencertableData = get(handles.sequencerTable,'Data');

% Init the sequencer
step_sequencer = 0;

%%% Sequencer Loop %%%

while step_sequencer < str2double(get(handles.sequencercollumnincrementEdittext,'String'))
    
    cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
    if cancelsequence_flag == 1
        set(handles.cancelsequenceButton,'UserData',0);
        break
        
    end
    
    step_sequencer = step_sequencer + 1;
    
    % Set the ref collumn counter
    
    set(handles.ref_sequencercollumnincrementText,'String',step_sequencer);
    
    %load_sequencerdata2sequencetable(handles,step);
    
    load_sequencerdata2sequencetable( handles,step_sequencer);
    
    % Setting Up the sequence loop (arguments)
    
    sequenceCondType = sequencertableData{2,step_sequencer};
    
    sequenceCondValue = str2double(sequencertableData{3,step_sequencer});
    
    sequenceStep = str2double(sequencertableData{4,step_sequencer});
    
    %sequenceCondCompare = sequencertableData{4,step};
    
    % Sequence Loop Switch
    
    switch sequenceCondType
        
        case 'Time' % Time
            
            total = tic;
            
            while sequenceCondValue > toc(total)
                
                cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
                if cancelsequence_flag == 1
                    
                    break
                    
                end
                
                if get(handles.absorbanceTogglebutton,'Value') == 1
                    
                    numberReadings = handles.numberReadings ;
                    number2Average = handles.number2Average ;
                    actuate_sequence_absorbance( handles,hObject,sequenceStep ,numberReadings,number2Average,step_sequencer );
                    
                else
                    
                    actuate_sequence_feedback_v2_special_char( hObject, handles,sequenceStep);
                    
                end
                
                disp('Time now : ');
                disp(toc(total));
                
            end
            
            
        case 'Cycle' % Cycle
            
            cycle_counter = 0 ;
            
            while cycle_counter < sequenceCondValue
                
                cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
                if cancelsequence_flag == 1
                    
                    break
                    
                end
                
                cycle_counter = cycle_counter + 1;
                
                disp('Current Cycle : ');
                disp(cycle_counter);

                if get(handles.absorbanceTogglebutton,'Value') == 1
                    
                    numberReadings = handles.numberReadings ;
                    number2Average = handles.number2Average ;
                    actuate_sequence_absorbance( handles,hObject,sequenceStep ,numberReadings,number2Average,step_sequencer );
                    
                else
                    
%                   actuate_sequence_v2( handles,hObject,sequenceStep );
                    actuate_sequence_feedback_v2_special_char( hObject, handles,sequenceStep);
                    
                end
                

            end
            
        case 'OD' % OD Value
            
            check_OD_value = 0 ;
            
            while check_OD_value < sequenceCondValue
                
                cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
                if cancelsequence_flag == 1
                    
                    break
                    
                end
                
               
                
                if get(handles.absorbanceTogglebutton,'Value') == 1
                    
                    numberReadings = handles.numberReadings ;
                    number2Average = handles.number2Average ;
                    check_OD_value = actuate_sequence_absorbance( handles,hObject,sequenceStep ,numberReadings,number2Average,step_sequencer,sequenceCondValue );
                    
                else
                    
                    actuate_sequence_feedback_v2_special_char( hObject, handles,sequenceStep);
                    
                end
                
            end
            
    end
    
end

%% Re-initialize stuff

set(handles.ref_sequencercollumnincrementText,'String',0);



% --- Executes on button press in pushbutton23.
function pushbutton23_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

actuate_sequence( handles,hObject,step_sequence );


% --- Executes on button press in loadsequencedataButton.
function loadsequencedataButton_Callback(hObject, eventdata, handles)
% hObject    handle to loadsequencedataButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load_sequencedata2sequencetable( handles);


function loadsequencestepEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to loadsequencestepEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of loadsequencestepEdittext as text
%        str2double(get(hObject,'String')) returns contents of loadsequencestepEdittext as a double


% --- Executes during object creation, after setting all properties.
function loadsequencestepEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to loadsequencestepEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in activateloadedseqeunceButton.
function activateloadedseqeunceButton_Callback(hObject, eventdata, handles)
% hObject    handle to activateloadedseqeunceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if get(handles.absorbanceTogglebutton,'Value') == 0
    
    sequenceStep = str2double(get(handles.loadsequencestepEdittext,'String'));
    
    actuate_sequence_special_char( handles,hObject,sequenceStep);
    
end

if get(handles.absorbanceTogglebutton,'Value') == 1
    
    error('Not Done Yet !');
    
    actuate_sequence_absorbance( handles,hObject,sequenceStep ,numberReadings,number2Average,step_sequencer);
    
end


% --- Executes on button press in inputtimesequenceButton.
function inputtimesequenceButton_Callback(hObject, eventdata, handles)
% hObject    handle to inputtimesequenceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

implement_time_sequence(handles);


% --- Executes on button press in singlecheckingstateButton.
function singlecheckingstateButton_Callback(hObject, eventdata, handles)
% hObject    handle to singlecheckingstateButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function electrodecirclecheckEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to electrodecirclecheckEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of electrodecirclecheckEdittext as text
%        str2double(get(hObject,'String')) returns contents of electrodecirclecheckEdittext as a double


% --- Executes during object creation, after setting all properties.
function electrodecirclecheckEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to electrodecirclecheckEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function divider4detectionEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to divider4detectionEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of divider4detectionEdittext as text
%        str2double(get(hObject,'String')) returns contents of divider4detectionEdittext as a double


% --- Executes during object creation, after setting all properties.
function divider4detectionEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to divider4detectionEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in functionGconnectButton.
function functionGconnectButton_Callback(hObject, eventdata, handles)
% hObject    handle to functionGconnectButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

disp_command(handles,'Connecting Function Generator...');

myFGen = fgen();
handles.myFGen = myFGen;
guidata(hObject,handles);

availableResources = getResources(myFGen)
%% Question : Which function generator you are using
% Construct a questdlg with three options
choice = questdlg('Which Function Generator are you using?', ...
	'Function Generator', ...
	'Desktop','Laptop','Cancel','Cancel');
% Handle response
switch choice
    case 'Desktop'
        myFGen.Resource = 'USB0::0x0957::0x1507::MY48016978::0::INSTR';
        
    case 'Laptop'
        myFGen.Resource = 'USB0::0x0957::0x1507::MY48017840::0::INSTR';
        
    case 'Cancel'
        
        disp('No Function Generator Connected');
end
%% Connecting Function Generator

connect(myFGen);
selectChannel(myFGen, '1');

disp_command(handles,'Done Connecting Function Generator...');

function functionGvoltageEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to functionGvoltageEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of functionGvoltageEdittext as text
%        str2double(get(hObject,'String')) returns contents of functionGvoltageEdittext as a double

voltageValue = str2double(get(hObject,'String'));

if (voltageValue > 3.7  || voltageValue < 1)
    
    set(hObject,'String','1');
    disp('VOLTAGE IS TOO HIGH or LOW BRO');
    
end

% --- Executes during object creation, after setting all properties.
function functionGvoltageEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to functionGvoltageEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function functionGfrequencyEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to functionGfrequencyEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of functionGfrequencyEdittext as text
%        str2double(get(hObject,'String')) returns contents of functionGfrequencyEdittext as a double

frequencyValue = str2double(get(hObject,'String'));

if (frequencyValue > 15000 || frequencyValue < 1000)
    
    set(hObject,'String','15000');
    disp('FREQUENCY IS TOO HIGH BRO');
    
end

% --- Executes during object creation, after setting all properties.
function functionGfrequencyEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to functionGfrequencyEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in functionGdisconnectButton.
function functionGdisconnectButton_Callback(hObject, eventdata, handles)
% hObject    handle to functionGdisconnectButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

disp_command(handles,'Disconnecting Function Generator...');

disconnect(handles.myFGen );
clear myFgen;

disp_command(handles,'Done Disconnecting Function Generator');

% --- Executes on button press in functionGlockTogglebutton.
function functionGlockTogglebutton_Callback(hObject, eventdata, handles)
% hObject    handle to functionGlockTogglebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of functionGlockTogglebutton

% Setting the Voltage and Frequency to be editable by the user

functionGlocktoggleState = get(hObject,'Value');

switch functionGlocktoggleState
    
    case 1
        
        % Disable the Ouput before making any changes
        
        disableOutput(handles.myFGen );
        
        set(handles.functionGbasevoltageEdittext,'Enable','on');
        
        set(handles.functionGjolttimeEdittext,'Enable','on');
        
        set(handles.functionGvoltageEdittext,'Enable','on');
        
        set(handles.functionGfrequencyEdittext,'Enable','on');
        
        set(hObject,'String','UNLOCKED','ForegroundColor','green');
        
        set(handles.functionGoutputTogglebutton,'Enable','off');
        
        set(handles.functionGoutputTogglebutton,'String','DISABLE','Foregroundcolor','red');
        
        set(handles.functionGoutputTogglebutton,'Value',0);
        
    case 0
        
        %Make funciton generator parameters Non-Editable when -> LOCK
        
        set(handles.functionGvoltageEdittext,'Enable','off');
        
        set(handles.functionGfrequencyEdittext,'Enable','off');
        
        set(handles.functionGbasevoltageEdittext,'Enable','off');
        
        set(handles.functionGjolttimeEdittext,'Enable','off');
        
        set(hObject,'String','LOCK','ForegroundColor','red');
        
        % Set the general Voltages and Frequency Here
        
        handles.myFGen.Amplitude = str2double(get(handles.functionGvoltageEdittext,'String'));
        
        handles.myFGen.Frequency = str2double(get(handles.functionGfrequencyEdittext,'String'));
        
        
        set(handles.functionGoutputTogglebutton,'Enable','on');
        
end


% --- Executes on button press in functionGoutputTogglebutton.
function functionGoutputTogglebutton_Callback(hObject, eventdata, handles)
% hObject    handle to functionGoutputTogglebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of functionGoutputTogglebutton

% Enable / Disable output

functionGoutputtoggleState = get(hObject,'Value');

switch functionGoutputtoggleState
    
    case 1
        
        enableOutput(handles.myFGen );
        
        set(hObject,'String','ENABLE','ForegroundColor','green');
        
    case 0
        
        disableOutput(handles.myFGen );
        
        set(hObject,'String','DISABLE','ForegroundColor','red');
        
end



function functionGbasevoltageEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to functionGbasevoltageEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of functionGbasevoltageEdittext as text
%        str2double(get(hObject,'String')) returns contents of functionGbasevoltageEdittext as a double

basevoltageValue = str2double(get(hObject,'String'));

if (basevoltageValue > 3.7  || basevoltageValue < 1)
    
    set(hObject,'String','1');
    disp('BASE VOLTAGE IS TOO HIGH or LOW BRO');
    
end


% --- Executes during object creation, after setting all properties.
function functionGbasevoltageEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to functionGbasevoltageEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function functionGjolttimeEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to functionGjolttimeEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of functionGjolttimeEdittext as text
%        str2double(get(hObject,'String')) returns contents of functionGjolttimeEdittext as a double


% --- Executes during object creation, after setting all properties.
function functionGjolttimeEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to functionGjolttimeEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function correctiontimeEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to correctiontimeEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of correctiontimeEdittext as text
%        str2double(get(hObject,'String')) returns contents of correctiontimeEdittext as a double


% --- Executes during object creation, after setting all properties.
function correctiontimeEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to correctiontimeEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function colorvalueEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to colorvalueEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of colorvalueEdittext as text
%        str2double(get(hObject,'String')) returns contents of colorvalueEdittext as a double


% --- Executes during object creation, after setting all properties.
function colorvalueEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to colorvalueEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in sequencerhelpButton.
function sequencerhelpButton_Callback(hObject, eventdata, handles)
% hObject    handle to sequencerhelpButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in loadcoordinatesPushbutton.
function loadcoordinatesPushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to loadcoordinatesPushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load_coordinates(handles);

% --- Executes on button press in savecoordinatesPushbutton.
function savecoordinatesPushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to savecoordinatesPushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

save_coordinates(handles);

function divider4checkingEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to divider4detectionEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of divider4detectionEdittext as text
%        str2double(get(hObject,'String')) returns contents of divider4detectionEdittext as a double


% --- Executes during object creation, after setting all properties.
function divider4checkingEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to divider4detectionEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in displaycoordinatesPushbutton.
function displaycoordinatesPushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to displaycoordinatesPushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mastertableData = get(handles.masterTable,'Data');

divider4checking = str2double(get(handles.divider4checkingEdittext,'String'));

%Taking a picture
screenshotgray_image = rgb2gray(getsnapshot(handles.vid ));

imshow(screenshotgray_image);

for i =1:1:104
    
    if mastertableData(i,2) == 0
        
        continue
        
    end
    
    position_x = mastertableData(i,2);
    
    position_y = mastertableData(i,3);
    
    %%% Squaring it (Detection Square)
    
    position_x_min = position_x - (handles.electrodeDimension/divider4checking);
    
    position_y_min = position_y - (handles.electrodeDimension/divider4checking);
    
    position_x_max = position_x + (handles.electrodeDimension/divider4checking);
    
    position_y_max = position_y + (handles.electrodeDimension/divider4checking);
    
    %%% Drawing the Detection box %%%
    
    viscircles([position_x_min position_y_min],10,'Color','b','Linestyle',':');
    
    viscircles([position_x_min position_y_max ],10,'Color','b','Linestyle',':');
    
    viscircles([position_x_max position_y_min],10,'Color','b','Linestyle',':');
    
    viscircles([position_x_max position_y_max ],10,'Color','b','Linestyle',':');
    
end


% --------------------------------------------------------------------
function feedbacksetupTool_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to feedbacksetupTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Prompt that asks user for the com of the arduino
prompt = {'Electrode Dimension','Droplet Radius','Divider','Base Time','Base Volt','Jolt Time','Jolt Voltage','Correction Time','General Grid Dimension','Grid Name','Grid Coordinates'};
dlg_title = 'Feedback Setup ';
num_lines = 1;
defaultans = {'0','0','0','0','0','0','0','0','0','visual_grid_','coordinates_'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

%answer_str = cell2mat(answer);

electrodeDimension = answer(1);
dropletRadius = answer(2);
divider = answer(3);
baseTime = answer(4);
baseVolt = answer(5);
joltTime = answer(6);
joltV = answer(7);
correctionTime = answer(8);
gridDimension = str2double(cell2mat(answer(9)));
%gridName = cell2mat(answer(10));
%gridCoordinates = cell2mat(answer(11));

set(handles.electrodedimensionEdittext,'String',electrodeDimension);
set(handles.dropletradiusEdittext,'String',dropletRadius);
set(handles.divider4checkingEdittext,'String',divider);
set(handles.basetimeEdittext,'String',baseTime);
set(handles.functionGbasevoltageEdittext,'String',baseVolt);
set(handles.functionGjolttimeEdittext,'String',joltTime);
set(handles.correctiontimeEdittext,'String',correctionTime);
set(handles.joltvEdittext,'String',joltV);



draw_grid_general(handles, gridDimension);
%draw_user_grid( handles, gridName);

%Loading in coordinates

% x_y_coordinates = load(gridCoordinates);
%
% Sending numbers to sequence table
% disp(sequencerData.sequencetableData{1,1});
%
% %Getting data from sequence table
% mastertableData = (get(handles.masterTable,'Data'));
%
% for i=1:1:104
%
%     mastertableData(i,2) = x_y_coordinates.saved_coordinates(i,1);
%     mastertableData(i,3) = x_y_coordinates.saved_coordinates(i,2);
%
% end
%
% set(handles.masterTable,'Data',mastertableData);


% --- Executes on button press in readblankButton.
function readblankButton_Callback(hObject, eventdata, handles)
% hObject    handle to readblankButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

implement_blankreading_sequence(handles );


% --- Executes on button press in testtoggleButton.
function testtoggleButton_Callback(hObject, eventdata, handles)
% hObject    handle to testtoggleButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of testtoggleButton


% --- Executes on button press in savevisualgridButton.
function savevisualgridButton_Callback(hObject, eventdata, handles)
% hObject    handle to savevisualgridButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
visualgridtableData = get(handles.visualgridTable,'Data');

dataSize = size (visualgridtableData);

visual_grid_coordinates = zeros(dataSize(1),dataSize(2));

for i = 1:1:dataSize(1)
    
    visual_grid_coordinates(i,1) = str2double(cell2mat(visualgridtableData(i,1)));
    visual_grid_coordinates(i,2) = str2double(cell2mat(visualgridtableData(i,2)));
    
end

% Saving coordinates to workspace (.mat file)

prompt = {'Save: '};
dlg_title = 'Save visual grid coordinates';
num_lines = 1;
defaultans = {'name'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

answer_text = cell2mat(answer);

filename = answer_text;

save(strcat('visual_grid_',filename), 'visual_grid_coordinates');

% --- Executes on button press in addrowButton.
function addrowButton_Callback(hObject, eventdata, handles)
% hObject    handle to addrowButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

data=get(handles.visualgridTable, 'data');
data(end+1,:)= {''};
set(handles.visualgridTable, 'data', data);


% --- Executes on button press in deletevisualgridButton.
function deletevisualgridButton_Callback(hObject, eventdata, handles)
% hObject    handle to deletevisualgridButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

lineObj1 = findobj(handles.previewvideobinaryAxe,'Type','line');

delete(lineObj1);


% --- Executes on button press in testvisualgridButton.
function testvisualgridButton_Callback(hObject, eventdata, handles)
% hObject    handle to testvisualgridButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
prompt = {'General Grid Dimension'};
dlg_title = 'Feedback Setup ';
num_lines = 1;
defaultans = {'0'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

gridDimension = str2double(cell2mat(answer(1)));

draw_grid_general( handles, gridDimension );


% --- Executes on button press in activatefeedbacksequenceButton.
function activatefeedbacksequenceButton_Callback(hObject, eventdata, handles)
% hObject    handle to activatefeedbacksequenceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

actuate_sequence_feedback_v2_special_char( hObject,handles,str2double(get(handles.loadsequencestepEdittext,'String')));

function joltvEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to joltvEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of joltvEdittext as text
%        str2double(get(hObject,'String')) returns contents of joltvEdittext as a double


% --- Executes during object creation, after setting all properties.
function joltvEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to joltvEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in colordetectionhelpButton.
function colordetectionhelpButton_Callback(hObject, eventdata, handles)
% hObject    handle to colordetectionhelpButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in saveluxButton.
function saveluxButton_Callback(hObject, eventdata, handles)
% hObject    handle to saveluxButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

luxtableData = get(handles.luxTable,'Data');

luxtableData_converted =  cell2table(luxtableData);

Filename = sprintf('lux_%s.xlsx', datestr(now,'mm-dd-yyyy-HH-MM'));

writetable(luxtableData_converted,Filename);


% --- Executes on button press in clearluxButton.
function clearluxButton_Callback(hObject, eventdata, handles)
% hObject    handle to clearluxButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

luxtableData = get(handles.luxTable,'Data');

for i = 1:1:500
    luxtableData(i,1) = {''};
    luxtableData(i,2) = {''};
end

set(handles.luxTable,'Data',luxtableData);


% --- Executes on button press in referenceelectrodeTogglebutton.
function referenceelectrodeTogglebutton_Callback(hObject, eventdata, handles)
% hObject    handle to referenceelectrodeTogglebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

referenceelectrodetoggleState = get(hObject,'Value');

switch referenceelectrodetoggleState
    
    case 0
        
        set(hObject,'ForegroundColor','Black');
        
    case 1
        
        set(hObject,'ForegroundColor','Red','FontWeight','Bold');
        mastertableData = get(handles.masterTable,'Data');
        
end

% --- Executes on button press in clearreferenceButton.
function clearreferenceButton_Callback(hObject, eventdata, handles)
% hObject    handle to clearreferenceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.inumberreferenceEdittext,'String',0);
set(handles.jnumberreferenceEdittext,'String',0);
set(handles.xreferencenumberEdittext,'String',0);
set(handles.yreferencenumberEdittext,'String',0);


% --- Executes on button press in clearcoordinatetableButton.
function clearcoordinatetableButton_Callback(hObject, eventdata, handles)
% hObject    handle to clearcoordinatetableButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mastertableData = get(handles.masterTable,'Data');

for i =1:1:104
    
    mastertableData(i,2) = 0;
    mastertableData(i,3) = 0;
    
end

set(handles.masterTable,'Data',mastertableData);


% --- Executes on button press in showcoordinatetableButton.
function showcoordinatetableButton_Callback(hObject, eventdata, handles)
% hObject    handle to showcoordinatetableButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mastertableData = get(handles.masterTable,'Data');

for i = 1:1:104
    
    x_position = mastertableData(i,2);
    y_position = mastertableData(i,3);
    
    if x_position == 0 || y_position == 0
        
        continue;
        
    end
    
    viscircles(handles.previewvideoAxe,[x_position y_position],10);
    
end


function inumberreferenceEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to inumberreferenceEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of inumberreferenceEdittext as text
%        str2double(get(hObject,'String')) returns contents of inumberreferenceEdittext as a double


% --- Executes during object creation, after setting all properties.
function inumberreferenceEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to inumberreferenceEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function jnumberreferenceEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to jnumberreferenceEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of jnumberreferenceEdittext as text
%        str2double(get(hObject,'String')) returns contents of jnumberreferenceEdittext as a double


% --- Executes during object creation, after setting all properties.
function jnumberreferenceEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to jnumberreferenceEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in clearpreviewvideoaxeButton.
function clearpreviewvideoaxeButton_Callback(hObject, eventdata, handles)
% hObject    handle to clearpreviewvideoaxeButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

lineObj = findobj(handles.previewvideoAxe,'Type','line');

delete(lineObj);


% --- Executes on button press in voltagechangesequenceButton.
function voltagechangesequenceButton_Callback(hObject, eventdata, handles)
% hObject    handle to voltagechangesequenceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

implement_voltage_sequence(handles);

% --- Executes on button press in actuationtimesequenceButton.
function actuationtimesequenceButton_Callback(hObject, eventdata, handles)
% hObject    handle to actuationtimesequenceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

implement_actuationtime_sequence(handles);


% --- Executes on button press in picturesequenceButton.
function picturesequenceButton_Callback(hObject, eventdata, handles)
% hObject    handle to picturesequenceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

implement_picture_sequence(handles);


% --- Executes on button press in referencesequenceButton.
function referencesequenceButton_Callback(hObject, eventdata, handles)
% hObject    handle to referencesequenceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

implement_reference_sequence(handles);

% --- Executes on button press in circlesequenceButton.
function circlesequenceButton_Callback(hObject, eventdata, handles)
% hObject    handle to circlesequenceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

implement_circle_sequence(handles);

function remaintimeEdittext_Callback(hObject, eventdata, handles)
% hObject    handle to remaintimeEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of remaintimeEdittext as text
%        str2double(get(hObject,'String')) returns contents of remaintimeEdittext as a double


% --- Executes during object creation, after setting all properties.
function remaintimeEdittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to remaintimeEdittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
