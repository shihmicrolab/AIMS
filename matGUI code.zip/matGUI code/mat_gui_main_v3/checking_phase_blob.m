function [ check_state ] = checking_phase_blob( handles,counter )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

set(handles.phaseButton,'BackgroundColor','magenta','String','CHECKING PHASE','Fontweight','bold');

% Taking the comparison image

normal_image = getsnapshot(handles.vid );

%save_image(normal_image,'Normal_C',counter,reactuation_flag,countNumReactuations);

compare_image = rgb2gray(getsnapshot(handles.vid ));

%save_image(compare_image,'Gray_C',counter,reactuation_flag,countNumReactuations);

difference_image = imabsdiff(handles.avg_reference_image,compare_image);

%save_image(difference_image,'Difference_C',counter,reactuation_flag,countNumReactuations);

difference_image_binary = imbinarize(difference_image);

%save_image(difference_image_binary,'Bina_C',counter,reactuation_flag,countNumReactuations);

%% Blob Analysis (Detecting Droplets)

obj.blobAnalyser = vision.BlobAnalysis('BoundingBoxOutputPort', true, ...
    'AreaOutputPort', true, 'CentroidOutputPort', true, ...
    'MinimumBlobArea', 400);

[~, centerdroplet, bboxes] = obj.blobAnalyser.step(difference_image_binary);

%% Showing the detection blob

difference_image_binary = im2uint8(difference_image_binary);
difference_image_binary = insertObjectAnnotation(difference_image_binary,'rectangle',bboxes,1);
imshow(difference_image_binary,'Parent',handles.comparepicAxe);
imshow(difference_image_binary,'Parent',handles.previewvideobinaryAxe);


%%


%%% Showing in another Figure

stepstr = int2str(counter);
 
filename = strcat('Circle_C','_',stepstr,'.png');

%figure('Name',filename);

%image_circles = imshow(difference_image_binary);

%viscircles(centerdroplet,radii);



% MASTER TABLE

% A 1 means = actuated electrode   OR   suppose to have a droplet there,
% but DOES NOT.

disp_command(handles,'CHECKING PHASE INITITATED');

% Getting the data from the  master table

mastertableData = get(handles.masterTable,'Data');

% Number of electrodes actuated

count = 0;

% Looking at how many electrodes succeed detection

successCount = 0;

% Checking the master table for the ones that get actuated

for i = 1:1:104
    
    if mastertableData(i,5) == 1
        
        count = count + 1;
        
    end
    
end

numbers_of_electrode_actuated = count ;

% STARTING TO CHECK HERE

for i = 1:1:104
    
    % Ignoring the Dispensing electrodes (putting them as succesful without checking)
    
    if mastertableData(i,8) == 1 && mastertableData(i,5) == 1
       
        c = 'Electrode ' ;
        d =  int2str(i);
        
        s2 = strcat(c,d);
        
            disp(s2);
            disp('worked');
            
            % Coloring the electrode yellow to indicate failure (blinking) (5x)
            
            color_electrode_pad_blink( i,'yellow', 3 , handles )
            
            % Setting the state in the master Table
            
            mastertableData(i,4) = 0;
            
            set(handles.masterTable,'Data',mastertableData);
            
            % Increment successCount by 1
            
            successCount = successCount + 1;
            
        continue
        
    end
    
    % Getting the data from the Table
    
    if mastertableData(i,5) == 1
        
        % Getting Electrode 'name'
        
        c = 'Electrode ' ;
        d =  int2str(i);
        
        s2 = strcat(c,d);
        
        % Getting the position x_y
        
        position_x = mastertableData(i,2);
        
        position_y = mastertableData(i,3);
        
        electrodeDimension = str2double(get(handles.electrodedimensionEdittext,'String'));
        %%% Squaring it (Detection Square)
        
        divider4checking = str2double(get(handles.divider4checkingEdittext,'String'));
        
        position_x_min = position_x - (electrodeDimension/divider4checking);
        
        position_y_min = position_y - (electrodeDimension/divider4checking);
        
        position_x_max = position_x + (electrodeDimension/divider4checking);
        
        position_y_max = position_y + (electrodeDimension/divider4checking);
        
        % Getting the size of the centerDroplet array (how many circles found)
        
        [m,n] = size(centerdroplet);
        
        % m = number of circles found ('row' of centerdroplet array)
        
        % Initializing sucess state of droplet 
        
         successState = 0;
        
        for t = 1:1:m
           
            % getting position from circle 
            position_x_circle = centerdroplet(t,1) ;
            position_y_circle = centerdroplet(t,2) ;
            
            if position_x_min < position_x_circle && position_x_circle <  position_x_max && position_y_min < position_y_circle && position_y_circle <  position_y_max
            
            % Marking the droplet as success
            
            successState = successState + 1;
            
            % Break out
            break
                
            end
            
        end
        
        % If success droplet actuation
        if successState == 1
            
            disp(s2);
            disp('worked');
            
            % Coloring the electrode yellow to indicate failure (blinking) (5x)
            
            color_electrode_pad_blink( i,'yellow', 3 , handles )
            
            % Setting the state in the master Table
            
            mastertableData(i,4) = 0;
            
            set(handles.masterTable,'Data',mastertableData);
            
            % Increment successCount by 1
            
            successCount = successCount + 1;
            
        % If failed droplet actuation
        else
            
            disp(s2);
            disp('failed');
            
            % Coloring the electrode red to indicate failure (blinking) (5x)
            
            color_electrode_pad_blink( i,'red', 3 , handles )
            
            % Setting the state in the master Table
            
            mastertableData(i,4) = 1;
            
            set(handles.masterTable,'Data',mastertableData);
            
        end
       
    end
    
end


% Looking at the total of the dispensing

if successCount == numbers_of_electrode_actuated % if all the droplet were actuated properly
    
    check_state = true;
    disp_command(handles,'Dispensing was succesful');
    
    % Re-Initialize the actuated number -> 0;
    
    for i = 1:1:104
        
        mastertableData(i,4) = 0;
        
        mastertableData(i,5) = 0;
        
        set(handles.masterTable,'Data',mastertableData);
        
    end
    
else
    
    % Re-Initializing the Actuated collumn (i,5) only
    
    for i = 1:1:104
        
        mastertableData(i,5) = 0;
        
        set(handles.masterTable,'Data',mastertableData);
        
    end
    
    check_state = false;
    disp_command(handles,'Dispensing failed');
    
end

disp (check_state);

disp_command(handles,'CHECKING PHASE TERMINATED');

% Deleting centerdroplet and radii (not sure if we really need this here)

delete centerdroplet 

delete radii

% Deleting the previous circles on the pictures first

delete h



end


