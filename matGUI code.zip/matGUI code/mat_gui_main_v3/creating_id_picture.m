function [  ] = creating_id_picture( handles,hObject )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

% Making a seperate figure

% Making a Figure
figure('Name','ID Picture Result','NumberTitle','off')

%Taking a picture
id_result_image = rgb2gray(getsnapshot(handles.vid ));

mastertableData = get(handles.masterTable,'Data');

for i = 1:1:104
    
    % Getting the data from the Table
    
    if mastertableData(i,1) ~= 0
        
        % Getting the position x_y
        
        position_x = mastertableData(i,2);
        
        position_y = mastertableData(i,3);
        
        
        
        %%% Squaring it
        
        position_x_t = position_x - 6;
        
        position_y_t = position_y - 5;
        
        
        
        %%% This is where you make the square (size of it) (Electrode ID)
        for i_s = 1:1:9
            for j_s = 1:1:12
                
               id_result_image(position_y_t + i_s, position_x_t + j_s) = 255 ;
                
                
            end
        end
        
      
        
    end
    
end

imshow(id_result_image);

%Showing the picture inside the axes 
imshow(id_result_image,'Parent',handles.idpicAxe);

end

