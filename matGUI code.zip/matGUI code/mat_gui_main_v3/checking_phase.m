function [ check_state ] = checking_phase( handles,counter )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

set(handles.phaseButton,'BackgroundColor','magenta','String','CHECKING PHASE','Fontweight','bold');

% Taking the comparison image

normal_image = getsnapshot(handles.vid );

%save_image(normal_image,'Normal_C',counter,reactuation_flag,countNumReactuations);

compare_image = rgb2gray(getsnapshot(handles.vid ));

%save_image(compare_image,'Gray_C',counter,reactuation_flag,countNumReactuations);

difference_image = imabsdiff(handles.avg_reference_image,compare_image);

%save_image(difference_image,'Difference_C',counter,reactuation_flag,countNumReactuations);

difference_image_binary = imbinarize(difference_image);

%save_image(difference_image_binary,'Bina_C',counter,reactuation_flag,countNumReactuations);

% Finding circles

% Getting the radius of Droplet from user and puttin a min and max for it

dropletRadiusMin = str2double(get(handles.dropletradiusEdittext,'String')) - 10;

dropletRadiusMax = str2double(get(handles.dropletradiusEdittext,'String')) + 10;

%% Center Finding
[centerdroplet1, radii1] = imfindcircles(difference_image_binary,[dropletRadiusMin dropletRadiusMax],'ObjectPolarity','bright','Sensitivity',0.97,'Method','TwoStage');
[centerdroplet2, radii2] = imfindcircles(difference_image_binary,[dropletRadiusMin*2 dropletRadiusMax*2],'ObjectPolarity','bright','Sensitivity',0.97,'Method','TwoStage');
[centerdroplet3, radii3] = imfindcircles(difference_image_binary,[dropletRadiusMin*3 dropletRadiusMax*3],'ObjectPolarity','bright','Sensitivity',0.97,'Method','TwoStage');

sd1 = size(centerdroplet1);
sd2 = size(centerdroplet2);
sd3 = size(centerdroplet3);

sd = sd1(1) + sd2(1) + sd3(1);

centerdroplet = zeros(sd,2);
radii = zeros(sd,1);

spaceCount = 0;

for i = 1:1:sd1(1)
    centerdroplet(spaceCount+i,1) = centerdroplet1(i,1);
    centerdroplet(spaceCount+i,2) = centerdroplet1(i,2);
    radii(spaceCount+i) = radii1(i);
   
    
end

spaceCount = sd1(1);

for i = 1:1:sd2(1)
    centerdroplet(spaceCount+i,1) = centerdroplet2(i,1);
    centerdroplet(spaceCount+i,2) = centerdroplet2(i,2);
    radii(spaceCount+i) = radii2(i);
    
end

spaceCount = sd1(1) + sd2(1);

for i = 1:1:sd3(1)
    centerdroplet(spaceCount+i,1) = centerdroplet3(i,1);
    centerdroplet(spaceCount+i,2) = centerdroplet3(i,2);
    radii(spaceCount+i) = radii3(i);
    
end

% %%% preview of the difference picture with circles %%%
% 
% imshow(difference_image_binary,'Parent',handles.comparepicAxe);
% 
% h = viscircles(handles.comparepicAxe,centerdroplet,radii);
% 
% circle_image_binary = getframe(handles.comparepicAxe);
% 
% stepstr = int2str(counter);
% 
% filename = strcat('Circle_C','_',stepstr,'.png');
% 
% imwrite(circle_image_binary.cdata,filename);


%%% preview of the difference picture with circles %%%

imshow(difference_image_binary,'Parent',handles.comparepicAxe);
imshow(difference_image_binary,'Parent',handles.previewvideobinaryAxe);

h = viscircles(handles.comparepicAxe,centerdroplet,radii);
h = viscircles(handles.previewvideobinaryAxe,centerdroplet,radii);

%%

%%% Showing in another Figure

stepstr = int2str(counter);
 
 filename = strcat('Circle_C','_',stepstr,'.png');

%figure('Name',filename);

%image_circles = imshow(difference_image_binary);

%viscircles(centerdroplet,radii);



% MASTER TABLE

% A 1 means = actuated electrode   OR   suppose to have a droplet there,
% but DOES NOT.

disp_command(handles,'CHECKING PHASE INITITATED');

% Getting the data from the  master table

mastertableData = get(handles.masterTable,'Data');

% Number of electrodes actuated

count = 0;

% Looking at how many electrodes succeed detection

successCount = 0;

% Checking the master table for the ones that get actuated

for i = 1:1:104
    
    if mastertableData(i,5) == 1
        
        count = count + 1;
        
    end
    
end

numbers_of_electrode_actuated = count ;

% STARTING TO CHECK HERE

for i = 1:1:104
    
    % Ignoring the Dispensing electrodes (putting them as succesful without checking)
    
    if mastertableData(i,8) == 1 && mastertableData(i,5) == 1
       
        c = 'Electrode ' ;
        d =  int2str(i);
        
        s2 = strcat(c,d);
        
            disp(s2);
            disp('worked');
            
            % Coloring the electrode yellow to indicate failure (blinking) (5x)
            
            color_electrode_pad_blink( i,'yellow', 3 , handles )
            
            % Setting the state in the master Table
            
            mastertableData(i,4) = 0;
            
            set(handles.masterTable,'Data',mastertableData);
            
            % Increment successCount by 1
            
            successCount = successCount + 1;
            
        continue
        
    end
    
    % Getting the data from the Table
    
    if mastertableData(i,5) == 1
        
        % Getting Electrode 'name'
        
        c = 'Electrode ' ;
        d =  int2str(i);
        
        s2 = strcat(c,d);
        
        % Getting the position x_y
        
        electrodeDimension = str2double(get(handles.electrodedimensionEdittext,'String'));
        
        position_x_center = mastertableData(i,2);
        
        position_y_center = mastertableData(i,3);
        
        disp(strcat('position_x_center : ',int2str(position_x_center)));
        disp(strcat('position_y_center : ',int2str(position_y_center)));
        
        
        %%% Squaring it (Detection Square)
        
        divider4checking = str2double(get(handles.divider4checkingEdittext,'String'));
        
        position_x_min = position_x_center - (electrodeDimension/divider4checking);
        
        position_y_min = position_y_center - (electrodeDimension/divider4checking);
        
        position_x_max = position_x_center + (electrodeDimension/divider4checking);
        
        position_y_max = position_y_center + (electrodeDimension/divider4checking);
        
        disp(strcat('position_x_min : ',int2str(position_x_min)));
        disp(strcat('position_x_max : ',int2str(position_x_max)));
        disp(strcat('position_y_min : ',int2str(position_y_min)));
        disp(strcat('position_y_max : ',int2str(position_y_max)));
        
        % Getting the size of the centerDroplet array (how many circles found)
        
        [m,n] = size(centerdroplet);
        
        % m = number of circles found ('row' of centerdroplet array)
        
        % Initializing sucess state of droplet 
        
         successState = 0;
        
        for t = 1:1:m
           
            % getting position from circle 
            position_x_circle = centerdroplet(t,1) ;
            position_y_circle = centerdroplet(t,2) ;
            
            disp(strcat('circle : ',int2str(t)));
            disp(strcat('position_x_circle : ',int2str(position_x_circle)));
            disp(strcat('position_y_circle : ',int2str(position_y_circle)));
            if position_x_min < position_x_circle && position_x_circle <  position_x_max && position_y_min < position_y_circle && position_y_circle <  position_y_max
            
            % Marking the droplet as success
            
            successState = successState + 1;
            
            % Break out
            break
                
            end
            
        end
        
        % If success droplet actuation
        if successState == 1
            
            disp(s2);
            disp('worked');
            
            % Coloring the electrode yellow to indicate failure (blinking) (5x)
            
            color_electrode_pad_blink( i,'yellow', 3 , handles )
            
            % Setting the state in the master Table
            
            mastertableData(i,4) = 0;
            
            set(handles.masterTable,'Data',mastertableData);
            
            % Increment successCount by 1
            
            successCount = successCount + 1;
            
        % If failed droplet actuation
        else
            
            disp(s2);
            disp('failed');
            
            % Coloring the electrode red to indicate failure (blinking) (5x)
            
            color_electrode_pad_blink( i,'red', 3 , handles )
            
            % Setting the state in the master Table
            
            mastertableData(i,4) = 1;
            
            set(handles.masterTable,'Data',mastertableData);
            
        end
       
    end
    
end


% Looking at the total of the dispensing

if successCount == numbers_of_electrode_actuated % if all the droplet were actuated properly
    
    check_state = true;
    disp_command(handles,'Dispensing was succesful');
    
    % Re-Initialize the actuated number -> 0;
    
    for i = 1:1:104
        
        mastertableData(i,4) = 0;
        
        mastertableData(i,5) = 0;
        
        set(handles.masterTable,'Data',mastertableData);
        
    end
    
else
    
    % Re-Initializing the Actuated collumn (i,5) only
    
    for i = 1:1:104
        
        mastertableData(i,5) = 0;
        
        set(handles.masterTable,'Data',mastertableData);
        
    end
    
    check_state = false;
    disp_command(handles,'Dispensing failed');
    
end

disp (check_state);

disp_command(handles,'CHECKING PHASE TERMINATED');

% Deleting centerdroplet and radii (not sure if we really need this here)

%delete centerdroplet 

%delete radii

% Deleting the previous circles on the pictures first

%delete h



end


