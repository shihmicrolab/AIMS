function [ absorbanceValue ] = get_absorbance_value(handles)

%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

disp_command(handles,'Getting Absorbance Value...');

luxValues = zeros(5);
avgLuxValue = 0;
sumLuxValue = 0;

for i =1:1:8
    
    fprintf(handles.arduino_absorbance,'T');
    
    fprintf(handles.arduino_absorbance,'R');
    
    luxValues(i) = fscanf(handles.arduino_absorbance,'%f');
    
    sumLuxValue =  sumLuxValue + luxValues(i);
    
    pause(0.25);
    
end

avgLuxValue = sumLuxValue / 8;

absorbanceValue = avgLuxValue; 

set(handles.luxreadingStatictext,'String',num2str(avgLuxValue));

disp(avgLuxValue);

disp_command(handles,'Done with Absorbance Value...');


end

