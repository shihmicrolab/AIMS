function [ check_OD_value ] = actuate_sequence_absorbance( handles,hObject,sequenceStep ,numberReadings,number2Average,step_sequencer,sequenceCondValue )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%% Absorbance Initializing

tic;

% Getting information from the lux Table

luxtableData = get(handles.luxTable,'Data');

% Checking if Absorbance option is requested

luxValues = zeros(numberReadings,1);

luxvaluesData = luxValues;

absorbancevalue_Counter = 0;

counter4time = 0;

time_counter = 0;

%Getting information from absorbance table

absorbancetableData = get(handles.absorbanceTable,'Data');

% Re-init the sequence table

for i = 1:1:120
    for j = 1:1:3
        
        absorbancetableData{i,j} = '';
        
    end
end

set(handles.absorbanceTable,'Data',absorbancetableData);

%% General Initializing

set(handles.phaseButton,'BackgroundColor','green','String','ACUTATION PHASE','Fontweight','bold');

%%% ACTIVATE_SEQUENCE_CODE %%%

disp_command(handles,'Sequence Activated');

handles = guidata(gcbo);

counter = 0 ;

j = 0;

% Getting information from the sequence table
sequencetableData = get(handles.sequenceTable,'Data');

%% Figure for Live Graphing of OD value

%figure('Name','OD Live Graph');
% 
% odLine = animatedline;
% ax = gca;
% ax.YGrid = 'on';
% ax.YLim = [0 3];
% 
% startTime = datetime('now');

%% Actuate Sequence

while counter ~= sequenceStep %+ 1
    
    counter = counter + 1 ;
    
    j = j + 1;
    
    % Setting the increment string to "activated" collumn
    
    set(handles.sequencecollumnincrementText,'String',int2str(j));
    
    handles = guidata(gcbo);
    
    % Checking if user press the cancel button
    
    cancelsequence_flag = get(handles.cancelsequenceButton,'UserData');
    
    if cancelsequence_flag == 1
        
        break
        
    end
    
    %% Checking for Special characters
    
    [ continue_statement, absorbancevalue_Counter, counter4time, time_counter,luxvaluesData,check_OD_value] = special_character_in_sequence( handles,luxvaluesData,j,absorbancevalue_Counter,counter4time,time_counter,number2Average );
    
    if check_OD_value > sequenceCondValue
       
        break;
        
    end
    
    if continue_statement == true
        
        continue
        
    end
    

    
    %% Electrode Actuating
    
    % Read the value of table and actuate the electrode
    
    for i = 1:1:6
        
        if isempty(sequencetableData{i,j}) == 1
            
            continue
            
        end
        
        %Turning electrode ON
        
        electrode_number = sequencetableData{i,j};
        
        actuate_electrode_multiple_on_noij( electrode_number,handles,hObject );
        
    end
    
    
    pause(str2double(get(handles.timeEdittext,'String')));
    
    
    for i = 1:1:6
        
        if isempty(sequencetableData{i,j}) == 1
            
            continue
            
        end

        %Turning electrode OFF
        
        electrode_number = sequencetableData{i,j};
        
        actuate_electrode_multiple_off_noij( electrode_number,handles );
        
    end
    
end
    

%% End of Sequence Operations

% Sending data to Excel

send_absorbance_data2excel_sequencer(handles,luxvaluesData, step_sequencer,numberReadings,number2Average );

% % Live Graph
% 
% [timeLogs,tempLogs] = getpoints(odLine);
% timeSecs = (timeLogs-timeLogs(1))*24*3600;
% figure('Name','OD Plot');
% plot(timeSecs,tempLogs);
% xlabel('Elapsed time (sec)');
% ylabel('OD Value');

%% Saving and clearing the Lux table data

luxtableData_converted =  cell2table(luxtableData);

Filename = sprintf('lux_backup_%s.xlsx', datestr(now,'mm-dd-yyyy-HH-MM'));

writetable(luxtableData_converted,Filename);


% Display that sequence is done

disp_command(handles,'Sequence Terminated');

% Setting the increment text back to 0

set(handles.sequencecollumnincrementText,'String','0');

% Set phase state

set(handles.phaseButton,'BackgroundColor','white','String','STAND-BY','Fontweight','bold');

end

