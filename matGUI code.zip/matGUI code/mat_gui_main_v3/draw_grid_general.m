function [  ] = draw_grid_general( handles, dimension )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

yGeneral = [1 1024];
yLine = 0;
xGeneral = [1 1280];
xLine = 0;

x = zeros(50);
y = zeros(50);

for i = 1:1:50
    
    xLine = dimension + xLine;
    x(i) = xLine;
    x(i,2) = xLine;
    line (handles.previewvideoAxe,[x(i) x(i,2)],yGeneral,'Color','red','LineWidth',1);
    line (handles.previewvideobinaryAxe,[x(i) x(i,2)],yGeneral,'Color','red','LineWidth',1);
    
end

for j = 1:1:50
    
    yLine = dimension + yLine;
    y(j) = yLine;
    y(j,2) = yLine;
    line (handles.previewvideoAxe,xGeneral,[y(j) y(j,2)],'Color','red','LineWidth',1);
    line (handles.previewvideobinaryAxe,xGeneral,[y(j) y(j,2)],'Color','red','LineWidth',1);

    
end

end

