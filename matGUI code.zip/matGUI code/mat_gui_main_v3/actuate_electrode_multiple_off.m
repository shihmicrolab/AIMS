function [  ] = actuate_electrode_multiple_off( i,j, electrode_number,handles )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

if get(handles.testtoggleButton,'Value') == 0
    
    % Converting the numbers from (user input) to which max we are talking.
    
    address  = conversion_2_arduino_address( handles , electrode_number );
    actNum  = conversion_2_arduino_actNum(  electrode_number );
    
    writeRegister(address,actNum,0);
    disp(['Electrode = ',int2str(electrode_number), ' turned OFF']);
    disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned OFF']);
    
    % Coloring the electrodes (white)
    color_electrode_pad( electrode_number,'white',handles );
    
else
    
    % Converting the numbers from (user input) to which max we are talking.
    
    % address  = conversion_2_arduino_address( handles , electrode_number );
    % actNum  = conversion_2_arduino_actNum(  electrode_number );
    %
    % writeRegister(address,actNum,0);
    disp(['Electrode = ',int2str(electrode_number), ' turned OFF']);
    disp_command(handles,['Electrode = ',int2str(electrode_number), ' turned OFF']);
    
    % Coloring the electrodes (white)
    color_electrode_pad( electrode_number,'white',handles );
    
end

end


